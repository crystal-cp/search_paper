# Literature Screening Decision Report

## Research Question

我想找关于薄膜沉积方法比较的综述，比如 ALD、PLD、sputtering 和 CVD 的优缺点。

## Question Preprocessing

Planning question: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.

Translated question: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.

## How the system corrected the user’s question

- User original wording: 我想找关于薄膜沉积方法比较的综述，比如 ALD、PLD、sputtering 和 CVD 的优缺点。
- Expert rewritten question: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.
- Downweighted user terms: review
- Expert concepts added: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, advantages disadvantages, comparison, ALD, PLD, ALD PLD sputtering, PLD sputtering CVD, ALD PLD, PLD sputtering, deposition methods, CVD, sputtering

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording: none recorded
- Selected interpretation: Not explicitly selected.
- Why this interpretation: Not generated in this run.
- User words not mechanically used as hard query terms: review

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| thin film deposition | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| atomic layer deposition | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| pulsed laser deposition | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| chemical vapor deposition | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| deposition methods | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| CVD | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| sputtering | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| advantages disadvantages | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| comparison | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| ALD | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| PLD | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| ALD PLD sputtering | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |
| PLD sputtering CVD | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |
| ALD PLD | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |
| PLD sputtering | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |

Downweighted terms: review

Optional or uncertain concepts: deposition methods, CVD, sputtering, advantages disadvantages, comparison, ALD, PLD, ALD PLD sputtering, PLD sputtering CVD, ALD PLD, PLD sputtering
- Assumptions needing confirmation or verification:
  - No domain-specific intent repair rules matched.
  - Do not treat broad motivation words as hard retrieval requirements.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.

## What the System Thinks the User Is Looking For

- Refined question: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Inclusion criteria: thin film review ald pld sputtering cvd, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, deposition methods, CVD, sputtering
- Exclusion criteria: 
- Required aspects: thin, film, review, background, significance, core concept coverage, method or measurement evidence
- Preferred paper types: review, survey, tutorial, methodological paper
- Time window: no strict time window
- Success definition: A small set of background papers plus clear concepts.

## Search Contract

- Domain: general_science
- Positive domains: science
- Negative domains: 
- Must include concepts: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition
- Must exclude concepts: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition
- Field whitelist: 
- Field blacklist: 

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, deposition methods, CVD, sputtering, advantages disadvantages, comparison, ALD, PLD, ALD PLD sputtering, PLD sputtering CVD, ALD PLD, PLD sputtering
- Must terms: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition
- Optional terms: deposition methods, CVD, sputtering, advantages disadvantages, comparison, ALD, PLD, ALD PLD sputtering, PLD sputtering CVD, ALD PLD
- Exclude terms: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'general_science', 'intent_domain': 'general_science', 'must_term_groups': [['thin film deposition', 'atomic layer deposition', 'pulsed laser deposition', 'chemical vapor deposition'], ['thin film deposition'], ['atomic layer deposition'], ['pulsed laser deposition'], ['chemical vapor deposition']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['thin film deposition', 'atomic layer deposition', 'pulsed laser deposition', 'chemical vapor deposition'], 'source': 'expert_intent', 'required': True}, {'group_name': 'optional_high_confidence', 'operator': 'OR', 'terms': ['deposition methods', 'CVD', 'sputtering', 'advantages disadvantages', 'comparison', 'ALD', 'PLD', 'ALD PLD sputtering', 'PLD sputtering CVD', 'ALD PLD', 'PLD sputtering'], 'source': 'expert_intent', 'required': False}, {'group_name': 'core_object_group_1', 'operator': 'OR', 'terms': ['thin film deposition'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_2', 'operator': 'OR', 'terms': ['atomic layer deposition'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_3', 'operator': 'OR', 'terms': ['pulsed laser deposition'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_4', 'operator': 'OR', 'terms': ['chemical vapor deposition'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['deposition methods', 'CVD', 'sputtering'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': [], 'intent_methods': ['deposition methods', 'CVD', 'sputtering'], 'intent_repair_used': True, 'structured_concepts': [{'term': 'review', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'thin film deposition', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'atomic layer deposition', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'pulsed laser deposition', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'chemical vapor deposition', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'deposition methods', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'CVD', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'sputtering', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'advantages disadvantages', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'comparison', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ALD', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'PLD', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ALD PLD sputtering', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'PLD sputtering CVD', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ALD PLD', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'PLD sputtering', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想找关于薄膜沉积方法比较的综述，比如 ALD、PLD、sputtering 和 CVD 的优缺点。
- Refined question: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Domain: general_science
- Must include concepts: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition
- Must exclude concepts: 
- Core terms: thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, deposition methods, CVD, sputtering, advantages disadvantages
- Expert rewrite: Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.
- Downweighted user terms: review

## 2. Concept decomposition

- Domain: general_science
- Central question: 我想找关于薄膜沉积方法比较的综述，比如 ALD、PLD、sputtering 和 CVD 的优缺点。 Find papers about thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition.
- core_topic: concepts=thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, ALD; methods=deposition methods, CVD, sputtering; materials=
- characterization_methods: concepts=thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, ALD; methods=deposition methods, CVD, sputtering; materials=
- method_comparison: concepts=thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, ALD; methods=deposition methods, CVD, sputtering, thin film deposition, atomic layer deposition; materials=

## 3. Search lenses and query families

- Query families generated: 3
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: "thin film deposition"; "thin film deposition" review \| semantic_scholar: "thin film deposition"; "thin film deposition" review
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: "thin film deposition"; "thin film deposition" characterization \| semantic_scholar: "thin film deposition"; "thin film deposition" characterization
- method_comparison (lens=method_comparison): compare alternative methods and their tradeoffs; sample queries=openalex: "thin film deposition"; "thin film deposition" "atomic layer deposition" "deposition methods" CVD sputtering "thin film deposition" "atomic layer deposition" "pulsed laser deposition" "chemical vapor deposition" ALD "comparison review" \| semantic_scholar: "thin film deposition"; "thin fil

## 4. Screening and inclusion criteria

- Inclusion criteria: thin film review ald pld sputtering cvd, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, deposition methods, CVD, sputtering
- Exclusion criteria: 
- Required aspects: thin, film, review, background, significance, core concept coverage, method or measurement evidence
- Contract inclusion criteria: thin film review ald pld sputtering cvd, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, deposition methods, CVD, sputtering
- Contract exclusion criteria: 

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 0 paper(s)
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 0 paper(s)
- review_background: 0 paper(s)

## 6. Research lineage

Not generated in this run.
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Theory and mechanism background is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Characterization methods are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Theory and mechanism background is undercovered: 
  - Characterization methods are undercovered: 
- Lens methods to audit: deposition methods, CVD, sputtering, thin film deposition, atomic layer deposition, pulsed laser deposition, chemical vapor deposition, ALD, PLD
- Lens materials to audit: 
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- "thin film deposition" "atomic layer deposition" "pulsed laser deposition" "research gap"
- "thin film deposition" "atomic layer deposition" "pulsed laser deposition" characterization method comparison

## 10. Verified vs uncertain findings

- Verified:
  - No strict or span-validated findings were available.
- Uncertain:
  - No uncertain findings were identified.
- Evidence functions observed: 

## Planned Queries

- "thin film deposition" "pulsed laser deposition"
- "thin film deposition" "chemical vapor deposition"
- "thin film deposition" "deposition methods"
- "thin film deposition" "pulsed laser deposition" characterization
- "thin film deposition" "chemical vapor deposition" characterization
- "thin film deposition" "atomic layer deposition" "deposition methods" CVD sputtering "thin film deposition" "atomic layer deposition" "pulsed laser deposition" "chemical vapor deposition" ALD "comparison review"
- "thin film deposition" "atomic layer deposition" "deposition methods" CVD sputtering "thin film deposition" "atomic layer deposition" "pulsed laser deposition" "chemical vapor deposition" ALD "advantages disadvantages"

## Domain Guardrails

- In scope: 0
- Borderline: 0
- Out of scope: 0

- No papers were demoted by domain guardrails.

## Query Pilot Diagnostics

- Pilot search was not run for this report.

## Query Repairs Applied

- Auto repair applied: False

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
|  |  |  |  | static_query_quality_repair |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 0
- Merged paper count: 0
- Duplicate count: 0
- Counts by provider: {'openalex': 0, 'semantic_scholar': 0}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 0
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 0
- Records identified by Semantic Scholar: 0
- Duplicate records removed: 0
- Records with missing abstracts: 0
- Records screened: 0
- Records included: 0
- Records maybe: 0
- Records excluded: 0
- Out-of-domain records: 0
- Included in top ranked results: 0
- Excluded or low confidence: 0
- Common exclusion reasons: {}

## Provider Status

| Provider | Status | Queries attempted | Papers returned | Notes |
| --- | --- | ---: | ---: | --- |
| openalex | not_attempted | 0 | 0 | stopped after 0 queries |
| semantic_scholar | not_attempted | 0 | 0 | stopped after 0 queries |

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

`strict_support` means the evidence sentence was grounded in the abstract. It is not a claim that the paper is highly relevant; use intent match and reading priority separately.

- Strict supported count: 0
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 0.000
- Strict support rate: 0.000
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.000

## Scoring Formula

`base_score = weighted relevance/evidence/recency/quality/diversity; pre_domain_score = 0.52 * intent_centrality_score + 0.48 * base_score when intent centrality is available; then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Evidence grounding | Intent match | Reading priority | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | ---: | --- | --- | --- |

## Included Papers

- No papers were automatically marked include.

## Maybe / Needs Human Inspection

- No papers were marked maybe.

## Excluded Papers And Reasons

- No papers were automatically excluded.

## Common Exclusion Reasons

- No exclusion reasons were recorded.

## Method Comparison Matrix

- No method comparison rows were generated.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Theory and mechanism background is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Synthesize theoretical background with experimentally grounded mechanism evidence. | theory_mechanism: theory; mechanism; model; explanation |
| Characterization methods are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Build a method-comparison table across direct, indirect, in situ, and ex situ probes. | methods_characterization: method; characterization; measurement; probe; experiment |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| "thin film deposition" "atomic layer deposition" "pulsed laser deposition" "research gap" | Investigate undercovered gap: Theory and mechanism background is undercovered | research_gap_matrix |
| "thin film deposition" "atomic layer deposition" "pulsed laser deposition" characterization method comparison | Investigate undercovered gap: Characterization methods are undercovered | research_gap_matrix |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

- No required aspects were classified.

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 0 papers
- recent_frontier: 0 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 0 papers
- background_or_survey: 0 papers
- peripheral: 0 papers
- excluded_or_low_confidence: 0 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.000
- Unsupported claim rate: 0.000
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: overview
- Planner: 7 planned query strings.
- Retriever: 0 raw records, 0 merged records.
- Domain guardrail: 0 in_scope, 0 borderline, 0 out_of_scope.
- Screening decision agent: 0 include, 0 maybe, 0 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
