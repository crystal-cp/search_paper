# Paper Evidence Cards

## 1. Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook

- Year / venue / citations: 2023 | Advanced Energy Materials | 729
- DOI or URL: 10.1002/aenm.202203307
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.861, relevance=0.579, evidence=0.818
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI).
- Evidence sentence: In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries

- Year / venue / citations: 2019 | Nanoscale | 183
- DOI or URL: 10.1039/c9nr05748j
- Decision: include
- Reading priority: must_read
- Recommended role: motivation
- Why relevant: score=0.840, relevance=0.519, evidence=0.855
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition.
- Evidence sentence: The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 3. The state of understanding of the lithium-ion-battery graphite solid electrolyte interphase (SEI) and its relationship to formation cycling

- Year / venue / citations: 2016 | Carbon | 2045
- DOI or URL: 10.1016/j.carbon.2016.04.008
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.837, relevance=0.573, evidence=0.855
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: methods_characterization
- Claim: An in-depth historical and current review is presented on the science of lithium-ion battery (LIB) solid electrolyte interphase (SEI) formation on the graphite anode, including structure, morphology, composition, electrochemistry, and formation mechanism.
- Evidence sentence: An in-depth historical and current review is presented on the science of lithium-ion battery (LIB) solid electrolyte interphase (SEI) formation on the graphite anode, including structure, morphology, composition, electrochemistry, and formation mechanism.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 4. Beyond Lithium‐Ion Batteries

- Year / venue / citations: 2024 | Advanced Functional Materials | 139
- DOI or URL: 10.1002/adfm.202308001
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.834, relevance=0.485, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: (article number 2303590) introduce a promising strategy for the atomically gradient solid electrolyte interphase (SEI) in AZIBs.
- Evidence sentence: (article number 2303590) introduce a promising strategy for the atomically gradient solid electrolyte interphase (SEI) in AZIBs.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 5. Solid Electrolyte Interface in Zn-Based Battery Systems

- Year / venue / citations: 2022 | Nano-Micro Letters | 224
- DOI or URL: 10.1007/s40820-022-00939-w
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.830, relevance=0.547, evidence=0.782
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background
- Claim: In Zn battery system, the battery performance is significantly affected by the solid electrolyte interface (SEI), which is controlled by electrode and electrolyte, and attracts dendrite growth, electrochemical stability window range, metallic Zn anode corrosion and passivation, and electrolyte mutations.
- Evidence sentence: In Zn battery system, the battery performance is significantly affected by the solid electrolyte interface (SEI), which is controlled by electrode and electrolyte, and attracts dendrite growth, electrochemical stability window range, metallic Zn anode corrosion and passivation, and electrolyte mutations.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 6. Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries

- Year / venue / citations: 2018 | npj Computational Materials | 1594
- DOI or URL: 10.1038/s41524-018-0064-0
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.828, relevance=0.594, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes.
- Evidence sentence: Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 7. Evaluation and Characterization of SEI Composition in Lithium Metal and Anode‐Free Lithium Batteries

- Year / venue / citations: 2025 | Advanced Energy Materials | 52
- DOI or URL: 10.1002/aenm.202501883
- Decision: include
- Reading priority: must_read
- Recommended role: evaluation
- Why relevant: score=0.822, relevance=0.487, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, methods_characterization, materials_cases, failure_limitation, SEI
- Missing aspects: theory_mechanism, solid electrolyte interphase
- Claim: Abstract Interfaces, particularly the solid electrolyte interface (SEI), play a crucial role in the performance and durability of batteries.
- Evidence sentence: Abstract Interfaces, particularly the solid electrolyte interface (SEI), play a crucial role in the performance and durability of batteries.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 8. Lithium-Ion Batteries

- Year / venue / citations: 2004 | PUBLISHED BY IMPERIAL COLLEGE PRESS AND DISTRIBUTED BY WORLD SCIENTIFIC PUBLISHING CO. eBooks | 431
- DOI or URL: 10.1142/p291
- Decision: include
- Reading priority: must_read
- Recommended role: motivation
- Why relevant: score=0.821, relevance=0.526, evidence=0.891
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, failure_limitation
- Claim: SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interphase on Positive and Negative Electrodes for Lithium-Ion Batteries (Z-X Wang et al.) Scanning Probe Microscopy Analysis of the SEI Formation on Graphite Anodes (M Inaba & Z Ogumi) Theoretical Insights into the SEI Components and Formation Mechanism: Density Functional Theory Studies (Y-X Wang & P B Balbuena) Continuum and Statistical Mechanics-Based Models for Solid-Electrolyte Interphases in Lithium-Ion Batteries (H J Ploehn et al.) Development of New Anodes for Rechargeable Lithium Batteries and Their SEI Characterization by Raman and NEXAFS Spectroscopy (G Sandi) The Cathode-Electrolyte Interface in a Li-Ion Battery (K Edstrom et al.) Theoretical Studies on the Structure, Association of Solvent, and Solvation of Li Ion: Implications to SEI Layer Phenomena (Y-X Wang & P B Balbuena).
- Evidence sentence: SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interphase on Positive and Negative Electrodes for Lithium-Ion Batteries (Z-X Wang et al.) Scanning Probe Microscopy Analysis of the SEI Formation on Graphite Anodes (M Inaba & Z Ogumi) Theoretical Insights into the SEI Components and Formation Mechanism: Density Functional Theory Studies (Y-X Wang & P B Balbuena) Continuum and Statistical Mechanics-Based Models for Solid-Electrolyte Interphases in Lithium-Ion Batteries (H J Ploehn et al.) Development of New Anodes for Rechargeable Lithium Batteries and Their SEI Characterization by Raman and NEXAFS Spectroscopy (G Sandi) The Cathode-Electrolyte Interface in a Li-Ion Battery (K Edstrom et al.) Theoretical Studies on the Structure, Association of Solvent, and Solvation of Li Ion: Implications to SEI Layer Phenomena (Y-X Wang & P B Balbuena).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 9. Analysis of Lithium‐Ion Battery State and Degradation via Physicochemical Cell and SEI Modeling

- Year / venue / citations: 2022 | Batteries & Supercaps | 34
- DOI or URL: 10.1002/batt.202200067
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.817, relevance=0.530, evidence=0.818
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background
- Claim: Abstract The quality of lithium‐ion batteries is affected by the formation of the solid electrolyte interphase (SEI).
- Evidence sentence: Abstract The quality of lithium‐ion batteries is affected by the formation of the solid electrolyte interphase (SEI).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 10. Operando spectral imaging of the lithium ion battery’s solid-electrolyte interphase

- Year / venue / citations: 2023 | Science Advances | 32
- DOI or URL: 10.1126/sciadv.adg5135
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.815, relevance=0.488, evidence=0.782
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background, methods_characterization
- Claim: Using ultrathin Li-ion cells, we acquire reference EELS spectra for the various constituents of the solid-electrolyte interphase (SEI) layer and then apply these “chemical fingerprints” to high-resolution, real-space mapping of the corresponding physical structures.
- Evidence sentence: Using ultrathin Li-ion cells, we acquire reference EELS spectra for the various constituents of the solid-electrolyte interphase (SEI) layer and then apply these “chemical fingerprints” to high-resolution, real-space mapping of the corresponding physical structures.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 11. An “Ether‐In‐Water” Electrolyte Boosts Stable Interfacial Chemistry for Aqueous Lithium‐Ion Batteries

- Year / venue / citations: 2020 | Advanced Materials | 153
- DOI or URL: 10.1002/adma.202004017
- Decision: include
- Reading priority: must_read
- Recommended role: motivation
- Why relevant: score=0.813, relevance=0.446, evidence=0.745
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background, theory_mechanism
- Claim: However, their voltage output and energy density are limited by the failure to form a solid‐electrolyte interphase (SEI) that can expand the inherently narrow electrochemical window of water (1.23 V) imposed by hydrogen and oxygen evolution.
- Evidence sentence: However, their voltage output and energy density are limited by the failure to form a solid‐electrolyte interphase (SEI) that can expand the inherently narrow electrochemical window of water (1.23 V) imposed by hydrogen and oxygen evolution.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 12. Development, retainment, and assessment of the graphite-electrolyte interphase in Li-ion batteries regarding the functionality of SEI-forming additives

- Year / venue / citations: 2022 | iScience | 81
- DOI or URL: 10.1016/j.isci.2022.103862
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.811, relevance=0.465, evidence=0.818
- Domain decision: in_scope
- Covered aspects: review_background, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: theory_mechanism, failure_limitation
- Claim: Formation of a decent solid-electrolyte interphase (SEI) is recognized as an approach to improve the performance of lithium-ion batteries.
- Evidence sentence: Formation of a decent solid-electrolyte interphase (SEI) is recognized as an approach to improve the performance of lithium-ion batteries.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include
