# Paper Evidence Cards

## 1. Spin-State Transition Enhanced Oxygen Evolving Activity in Misfit-Layered Cobalt Oxide Nanosheets

- Year / venue / citations: 2018 | ACS Sustainable Chemistry and Engineering | 12
- DOI or URL: 10.1021/acssuschemeng.8b02804
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.753, relevance=0.380, evidence=0.745
- Domain decision: in_scope
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: Transition-metal oxides and their derivatives have been explored as OER catalyst candidates owing to their earth-abundant reserves and environment-friendly features.
- Evidence sentence: Transition-metal oxides and their derivatives have been explored as OER catalyst candidates owing to their earth-abundant reserves and environment-friendly features.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Breaking the Activity and Stability Bottlenecks of Electrocatalysts for Oxygen Evolution Reactions in Acids

- Year / venue / citations: 2023 | Advanced Materials | 320
- DOI or URL: 10.1002/adma.202211884
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.474, relevance=0.341, evidence=0.673
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: Here, the recent advances in OER electrocatalysis in acids are reviewed and the key strategies are summarized to overcome the bottlenecks of activity and stability for both noble-metal-based and noble metal-free catalysts, including i) morphology engineering, ii) composition engineering, and iii) defect engineering.
- Evidence sentence: Here, the recent advances in OER electrocatalysis in acids are reviewed and the key strategies are summarized to overcome the bottlenecks of activity and stability for both noble-metal-based and noble metal-free catalysts, including i) morphology engineering, ii) composition engineering, and iii) defect engineering.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 3. The Ir–OOOO–Ir transition state and the mechanism of the oxygen evolution reaction on IrO <sub>2</sub> (110)

- Year / venue / citations: 2022 | Energy & Environmental Science | 121
- DOI or URL: 10.1039/d2ee00158f
- Decision: maybe
- Reading priority: optional
- Recommended role: evaluation
- Why relevant: score=0.474, relevance=0.365, evidence=0.782
- Domain decision: borderline
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: review_background, controversy_debate, surface spin state
- Claim: The establishment of surface oxygen atoms as fixed electrocatalytically active sites on a transition-metal oxide represents a paradigm shift for the understanding of water oxidation electrocatalysis, and it reconciles the theoretical understanding of the OER mechanism on iridium oxide with recently reported experimental results from operando X-ray spectroscopy.
- Evidence sentence: The establishment of surface oxygen atoms as fixed electrocatalytically active sites on a transition-metal oxide represents a paradigm shift for the understanding of water oxidation electrocatalysis, and it reconciles the theoretical understanding of the OER mechanism on iridium oxide with recently reported experimental results from operando X-ray spectroscopy.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 4. Advanced Transition Metal‐Based OER Electrocatalysts: Current Status, Opportunities, and Challenges

- Year / venue / citations: 2021 | Small | 984
- DOI or URL: 10.1002/smll.202100129
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.473, relevance=0.388, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Evidence sentence: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 5. Spin Effects in Chemisorption and Catalysis

- Year / venue / citations: 2023 | ACS Catalysis | 150
- DOI or URL: 10.1021/acscatal.2c06319
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.468, relevance=0.352, evidence=0.745
- Domain decision: borderline
- Covered aspects: theory_mechanism, materials_cases, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate, OER
- Claim: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Evidence sentence: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 6. Trends and Prospects of Bulk and Single‐Atom Catalysts for the Oxygen Evolution Reaction

- Year / venue / citations: 2023 | Advanced Energy Materials | 126
- DOI or URL: 10.1002/aenm.202203913
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.468, relevance=0.264, evidence=0.673
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: Starting from the established understanding of the OER mechanism, it offers an overview of state‐of‐the‐art materials for the OER, highlighting the current research directions and shortcomings of bulk electrocatalysts.
- Evidence sentence: Starting from the established understanding of the OER mechanism, it offers an overview of state‐of‐the‐art materials for the OER, highlighting the current research directions and shortcomings of bulk electrocatalysts.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 7. Spin-polarized oxygen evolution reaction under magnetic field

- Year / venue / citations: 2021 | Nature Communications | 683
- DOI or URL: 10.1038/s41467-021-22865-y
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.467, relevance=0.360, evidence=0.709
- Domain decision: borderline
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: We found that the spin polarization occurs at the first electron transfer step in OER, where coherent spin exchange happens between the ferromagnetic catalyst and the adsorbed oxygen species with fast kinetics, under the principle of spin angular momentum conservation.
- Evidence sentence: We found that the spin polarization occurs at the first electron transfer step in OER, where coherent spin exchange happens between the ferromagnetic catalyst and the adsorbed oxygen species with fast kinetics, under the principle of spin angular momentum conservation.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 8. Spin‐Regulated Fenton‐Like Catalysis for Nonradical Oxidation over Metal Oxide@Carbon Composites

- Year / venue / citations: 2024 | Advanced Functional Materials | 64
- DOI or URL: 10.1002/adfm.202401397
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.466, relevance=0.371, evidence=0.745
- Domain decision: borderline
- Covered aspects: materials_cases, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate, OER
- Claim: The spin state of the transition metal species (TMs) has been recognized as a critical descriptor in Fenton‐like catalysis.
- Evidence sentence: The spin state of the transition metal species (TMs) has been recognized as a critical descriptor in Fenton‐like catalysis.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 9. Beyond conventional structures: emerging complex metal oxides for efficient oxygen and hydrogen electrocatalysis

- Year / venue / citations: 2024 | Chemical Society Reviews | 172
- DOI or URL: 10.1039/d3cs01020a
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.461, relevance=0.311, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, methods_characterization, materials_cases, OER
- Missing aspects: theory_mechanism, controversy_debate, surface spin state
- Claim: Subsequently, we present a thorough overview of various complex metal oxides reported for ORR, OER, and HER electrocatalysis thus far, such as double/triple/quadruple perovskites, perovskite hydroxides, brownmillerites, Ruddlesden-Popper oxides, Aurivillius oxides, lithium/sodium transition metal oxides, pyrochlores, metal phosphates, polyoxometalates and other specially structured oxides, with emphasis on the designed strategies for promoting their performance and structure-property-performance relationships.
- Evidence sentence: Subsequently, we present a thorough overview of various complex metal oxides reported for ORR, OER, and HER electrocatalysis thus far, such as double/triple/quadruple perovskites, perovskite hydroxides, brownmillerites, Ruddlesden-Popper oxides, Aurivillius oxides, lithium/sodium transition metal oxides, pyrochlores, metal phosphates, polyoxometalates and other specially structured oxides, with emphasis on the designed strategies for promoting their performance and structure-property-performance relationships.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 10. Identification of Surface Reactivity Descriptor for Transition Metal Oxides in Oxygen Evolution Reaction

- Year / venue / citations: 2016 | Journal of the American Chemical Society | 462
- DOI or URL: 10.1021/jacs.6b05398
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.460, relevance=0.390, evidence=0.745
- Domain decision: borderline
- Covered aspects: theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate
- Claim: A number of important reactions such as the oxygen evolution reaction (OER) are catalyzed by transition metal oxides (TMOs), the surface reactivity of which is rather elusive.
- Evidence sentence: A number of important reactions such as the oxygen evolution reaction (OER) are catalyzed by transition metal oxides (TMOs), the surface reactivity of which is rather elusive.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 11. The electronic structure of transition metal oxides for oxygen evolution reaction

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 261
- DOI or URL: 10.1039/d1ta03732c
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.459, relevance=0.339, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Evidence sentence: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 12. A highly active and stable IrO <i> <sub>x</sub> </i> /SrIrO <sub>3</sub> catalyst for the oxygen evolution reaction

- Year / venue / citations: 2016 | Science | 2163
- DOI or URL: 10.1126/science.aaf5050
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.458, relevance=0.347, evidence=0.745
- Domain decision: borderline
- Covered aspects: theory_mechanism, materials_cases, OER
- Missing aspects: review_background, methods_characterization, controversy_debate, surface spin state
- Claim: This catalyst has demonstrated specific activity at 10 milliamps per square centimeter of oxide catalyst (OER current normalized to catalyst surface area), with only 270 to 290 millivolts of overpotential for 30 hours of continuous testing in acidic electrolyte.
- Evidence sentence: This catalyst has demonstrated specific activity at 10 milliamps per square centimeter of oxide catalyst (OER current normalized to catalyst surface area), with only 270 to 290 millivolts of overpotential for 30 hours of continuous testing in acidic electrolyte.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain
