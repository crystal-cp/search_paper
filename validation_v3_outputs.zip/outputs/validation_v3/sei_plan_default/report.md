# Literature Screening Decision Report

## Research Question

我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。

## Question Preprocessing

Planning question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.

Translated question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.

## How the system corrected the user’s question

- User original wording: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。
- Expert rewritten question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Downweighted user terms: importance, significance
- Expert concepts added: solid electrolyte interphase, SEI, representative material systems, theoretical background, ex situ, in situ, SEI SEI, failure mechanism, lithium-ion battery, interface, in situ characterization, ex situ characterization, characterization

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording:
  - direct citation or same-author related papers
  - topic-related papers
  - method-related papers
  - application-related papers
  - theory-lineage related papers
  - background or review papers
  - evidence papers that demonstrate why the effect matters
  - application or device-motivation papers
- Selected interpretation: topic + method + theory-lineage related papers
- Why this interpretation: The question mentions research concepts and probe goals, but no verified citation relation; topical, methodological, and theory-lineage relevance is the safest default.
- Ambiguity points:
  - The phrase 'related papers' is ambiguous: it may mean direct citation, same author, topical similarity, method overlap, application relevance, or theory lineage.
  - The motivation word 'importance/significance' may ask for background, evidence papers, application motivation, or device relevance.
- Needs user confirmation:
  - Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance.
  - Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Unsafe or overbroad assumptions avoided:
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.
  - Do not collapse 'importance' into only review/survey/tutorial queries.
- User words not mechanically used as hard query terms: importance, significance

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| solid electrolyte interphase | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| SEI | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| lithium-ion battery | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| interface | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| composition | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| structure | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| evolution | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| in situ characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| ex situ characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| failure mechanism | mechanism | user_text | optional | yes | User asks for theory or mechanism evidence. |
| representative material systems | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| theoretical background | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| ex situ | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| in situ | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| SEI SEI | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |

Downweighted terms: importance, significance

Optional or uncertain concepts: lithium-ion battery, interface, composition, structure, evolution, in situ characterization, ex situ characterization, characterization, failure mechanism, representative material systems, theoretical background, ex situ, in situ, SEI SEI

Needs user confirmation: Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance., Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Assumptions needing confirmation or verification:
  - No domain-specific intent repair rules matched.
  - Do not treat broad motivation words as hard retrieval requirements.
  - Assume 'related papers' means topic + method + theory-lineage relevance unless the user asks for citation or author-only expansion.
  - Treat 'importance' as a request for background plus evidence and application/device motivation, not only review articles.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.
  - Do not collapse 'importance' into only review/survey/tutorial queries.

## What the System Thinks the User Is Looking For

- Refined question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, in situ characterization, ex situ characterization, characterization
- Exclusion criteria: 
- Required aspects: interface, materials, experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Preferred paper types: review, survey, tutorial, methodological paper, theoretical paper
- Time window: no strict time window
- Success definition: A small set of background papers plus clear concepts.

## Search Contract

- Domain: general_science
- Positive domains: science
- Negative domains: 
- Must include concepts: solid electrolyte interphase, SEI
- Must exclude concepts: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, solid electrolyte interphase, SEI
- Field whitelist: 
- Field blacklist: 

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: solid electrolyte interphase, SEI, lithium-ion battery, interface, composition, structure, evolution, in situ characterization, ex situ characterization, characterization, failure mechanism, representative material systems, theoretical background, ex situ, in situ, SEI SEI
- Must terms: solid electrolyte interphase, SEI
- Optional terms: lithium-ion battery, interface, composition, structure, evolution, in situ characterization, ex situ characterization, characterization, failure mechanism, representative material systems
- Exclude terms: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, solid electrolyte interphase, SEI
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'general_science', 'intent_domain': 'general_science', 'must_term_groups': [['solid electrolyte interphase', 'SEI'], ['solid electrolyte interphase', 'SEI'], ['lithium-ion battery', 'electrolyte', 'battery']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['solid electrolyte interphase', 'SEI'], 'source': 'expert_intent', 'required': True}, {'group_name': 'optional_high_confidence', 'operator': 'OR', 'terms': ['lithium-ion battery', 'interface', 'composition', 'structure', 'evolution', 'in situ characterization', 'ex situ characterization', 'characterization', 'failure mechanism', 'representative material systems', 'theoretical background', 'ex situ', 'in situ', 'SEI SEI'], 'source': 'expert_intent', 'required': False}, {'group_name': 'core_object_group', 'operator': 'OR', 'terms': ['solid electrolyte interphase', 'SEI'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'domain_context_group', 'operator': 'OR', 'terms': ['lithium-ion battery', 'electrolyte', 'battery'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'process_or_property_group', 'operator': 'OR', 'terms': ['composition', 'structure', 'evolution'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['in situ characterization', 'ex situ characterization', 'characterization'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'mechanism_group', 'operator': 'OR', 'terms': ['failure mechanism'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'material_or_case_group', 'operator': 'OR', 'terms': ['lithium-ion battery', 'interface'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'failure_or_limitation_group', 'operator': 'OR', 'terms': ['failure mechanism'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': ['lithium-ion battery', 'interface'], 'intent_methods': ['in situ characterization', 'ex situ characterization', 'characterization'], 'intent_repair_used': True, 'structured_concepts': [{'term': 'importance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'significance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'solid electrolyte interphase', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'SEI', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'lithium-ion battery', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'interface', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'composition', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'structure', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'evolution', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'in situ characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ex situ characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'failure mechanism', 'category': 'mechanism', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for theory or mechanism evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'representative material systems', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'theoretical background', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ex situ', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'in situ', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'SEI SEI', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。
- Refined question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Domain: general_science
- Must include concepts: solid electrolyte interphase, SEI
- Must exclude concepts: 
- Core terms: solid electrolyte interphase, SEI, lithium-ion battery, interface, composition, structure, evolution, in situ characterization
- Expert rewrite: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Downweighted user terms: importance, significance

## 2. Concept decomposition

- Domain: general_science
- Central question: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。 Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- core_topic: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=in situ characterization, ex situ characterization, characterization; materials=lithium-ion battery, interface, electrolyte, battery
- theory_mechanism: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=in situ characterization, ex situ characterization, characterization; materials=lithium-ion battery, interface, electrolyte, battery
- characterization_methods: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=in situ characterization, ex situ characterization, characterization; materials=lithium-ion battery, interface, electrolyte, battery
- materials_or_cases: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=in situ characterization, ex situ characterization, characterization; materials=lithium-ion battery, interface, electrolyte, battery
- failure_or_limitation: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=in situ characterization, ex situ characterization, characterization; materials=lithium-ion battery, interface, electrolyte, battery

## 3. Search lenses and query families

- Query families generated: 5
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" "lithium-ion battery" review \| semantic_scholar: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" "lithium-ion battery" review
- theory_mechanism (lens=theory_mechanism): find theory, mechanism, model, or causal-relation papers; sample queries=openalex: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" composition "lithium-ion battery" mechanism \| semantic_scholar: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" composition "lithium-ion battery" mechanism
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: "solid electrolyte interphase" "lithium-ion battery"; SEI "lithium-ion battery" characterization \| semantic_scholar: "solid electrolyte interphase" "lithium-ion battery"; SEI "lithium-ion battery" characterization
- materials_or_cases (lens=materials_or_cases): find representative materials, systems, benchmarks, or case studies; sample queries=openalex: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" "lithium-ion battery" "case study" \| semantic_scholar: "solid electrolyte interphase" "lithium-ion battery"; "solid electrolyte interphase" "lithium-ion battery" "case study"
- failure_or_limitation (lens=failure_or_limitation): find failure modes, degradation, limitations, or boundary conditions; sample queries=openalex: "solid electrolyte interphase" "lithium-ion battery"; SEI "failure mechanism" "lithium-ion battery" \| semantic_scholar: "solid electrolyte interphase" "lithium-ion battery"; SEI "failure mechanism" "lithium-ion battery"

## 4. Screening and inclusion criteria

- Inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, in situ characterization, ex situ characterization
- Exclusion criteria: 
- Required aspects: interface, materials, experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Contract inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, in situ characterization, ex situ characterization
- Contract exclusion criteria: 

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 0 paper(s)
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 0 paper(s)
- review_background: 0 paper(s)

## 6. Research lineage

Not generated in this run.
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Theory and mechanism background is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Characterization methods are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Representative material cases are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Failure mechanisms are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Theory and mechanism background is undercovered: 
  - Characterization methods are undercovered: 
  - Representative material cases are undercovered: 
  - Failure mechanisms are undercovered: 
- Lens methods to audit: in situ characterization, ex situ characterization, characterization
- Lens materials to audit: lithium-ion battery, interface, electrolyte, battery
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- "solid electrolyte interphase" SEI "research gap"
- "solid electrolyte interphase" SEI characterization method comparison
- "solid electrolyte interphase" SEI representative material case study
- "solid electrolyte interphase" SEI "failure mechanism" degradation

## 10. Verified vs uncertain findings

- Verified:
  - No strict or span-validated findings were available.
- Uncertain:
  - No uncertain findings were identified.
- Evidence functions observed: 

## Planned Queries

- "solid electrolyte interphase" "lithium-ion battery"
- "solid electrolyte interphase" "lithium-ion battery" review
- SEI "lithium-ion battery" background
- SEI "lithium-ion battery" composition
- SEI "lithium-ion battery" structure
- "solid electrolyte interphase" composition "lithium-ion battery" mechanism
- SEI composition interface theory
- SEI "lithium-ion battery" characterization
- "solid electrolyte interphase" "lithium-ion battery" "in situ characterization"
- SEI composition characterization "lithium-ion battery"
- SEI structure characterization "lithium-ion battery"
- "solid electrolyte interphase" "lithium-ion battery" "case study"

## Domain Guardrails

- In scope: 0
- Borderline: 0
- Out of scope: 0

- No papers were demoted by domain guardrails.

## Query Pilot Diagnostics

- Pilot search was not run for this report.

## Query Repairs Applied

- Auto repair applied: False

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
|  |  |  |  | static_query_quality_repair |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 0
- Merged paper count: 0
- Duplicate count: 0
- Counts by provider: {'openalex': 0, 'semantic_scholar': 0}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 0
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 0
- Records identified by Semantic Scholar: 0
- Duplicate records removed: 0
- Records with missing abstracts: 0
- Records screened: 0
- Records included: 0
- Records maybe: 0
- Records excluded: 0
- Out-of-domain records: 0
- Included in top ranked results: 0
- Excluded or low confidence: 0
- Common exclusion reasons: {}

## Provider Status

| Provider | Status | Queries attempted | Papers returned | Notes |
| --- | --- | ---: | ---: | --- |
| openalex | not_attempted | 0 | 0 | stopped after 0 queries |
| semantic_scholar | not_attempted | 0 | 0 | stopped after 0 queries |

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

`strict_support` means the evidence sentence was grounded in the abstract. It is not a claim that the paper is highly relevant; use intent match and reading priority separately.

- Strict supported count: 0
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 0.000
- Strict support rate: 0.000
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.000

## Scoring Formula

`base_score = weighted relevance/evidence/recency/quality/diversity; pre_domain_score = 0.52 * intent_centrality_score + 0.48 * base_score when intent centrality is available; then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Evidence grounding | Intent match | Reading priority | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | ---: | --- | --- | --- |

## Included Papers

- No papers were automatically marked include.

## Maybe / Needs Human Inspection

- No papers were marked maybe.

## Excluded Papers And Reasons

- No papers were automatically excluded.

## Common Exclusion Reasons

- No exclusion reasons were recorded.

## Method Comparison Matrix

- No method comparison rows were generated.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Theory and mechanism background is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Synthesize theoretical background with experimentally grounded mechanism evidence. | theory_mechanism: theory; mechanism; model; explanation |
| Characterization methods are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Build a method-comparison table across direct, indirect, in situ, and ex situ probes. | methods_characterization: method; characterization; measurement; probe; experiment |
| Representative material cases are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Benchmark representative materials or systems rather than relying on one prototype. | materials_cases: material; system; case study; benchmark |
| Failure mechanisms are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Map failure, degradation, and aging pathways to material systems and diagnostics. | failure_limitation: failure; limitation; degradation; aging; stability |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| "solid electrolyte interphase" SEI "research gap" | Investigate undercovered gap: Theory and mechanism background is undercovered | research_gap_matrix |
| "solid electrolyte interphase" SEI characterization method comparison | Investigate undercovered gap: Characterization methods are undercovered | research_gap_matrix |
| "solid electrolyte interphase" SEI representative material case study | Investigate undercovered gap: Representative material cases are undercovered | research_gap_matrix |
| "solid electrolyte interphase" SEI "failure mechanism" degradation | Investigate undercovered gap: Failure mechanisms are undercovered | research_gap_matrix |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

- No required aspects were classified.

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 0 papers
- recent_frontier: 0 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 0 papers
- background_or_survey: 0 papers
- peripheral: 0 papers
- excluded_or_low_confidence: 0 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.000
- Unsupported claim rate: 0.000
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: overview
- Planner: 12 planned query strings.
- Retriever: 0 raw records, 0 merged records.
- Domain guardrail: 0 in_scope, 0 borderline, 0 out_of_scope.
- Screening decision agent: 0 include, 0 maybe, 0 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
