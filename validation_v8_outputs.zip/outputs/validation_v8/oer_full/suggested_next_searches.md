# Suggested Next Searches

| query | reason | source |
| --- | --- | --- |
| OER "spin state" operando spectroscopy | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| OER "surface reconstruction" "spin state" catalyst | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| OER "lattice oxygen mechanism" "spin state" | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| "oxygen evolution reaction" "electronic structure" perovskite oxide | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| OER "surface spin state" | Pilot search flagged drift for query: "surface spin state" | query_pilot_diagnostics |
| OER "surface spin state" spin oxygen evolution | Expand around keywords from currently included papers. | included_paper_keywords |
