# Suggested Next Searches

| query | reason | source |
| --- | --- | --- |
| SEI "in situ" characterization "lithium-ion battery" | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| SEI "ex situ" characterization "lithium-ion battery" | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| "solid electrolyte interphase" composition evolution "lithium-ion battery" | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| SEI failure mechanism "lithium-ion battery" | Optional follow-up to check depth and recency for a specific user-requested aspect. | research_gap_matrix |
| "solid electrolyte interphase" SEI | Pilot search flagged drift for query: "solid electrolyte interphase" | query_pilot_diagnostics |
| "solid electrolyte interphase" SEI electrolyte lithium solid | Expand around keywords from currently included papers. | included_paper_keywords |
