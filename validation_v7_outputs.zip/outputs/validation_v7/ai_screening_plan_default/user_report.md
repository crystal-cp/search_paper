# User-Friendly Literature Screening Summary

## Retrieval status

- retrieval_status: planning_only
- provider_summary: openalex:not_attempted(0 papers); semantic_scholar:not_attempted(0 papers)
- ranked papers based on real retrieval: False

## How the system interpreted the task

The system split the question into intent groups, query families, domain checks, and evidence-grounded paper summaries.

本次只完成 query planning，未执行论文检索，因此不生成 research gaps，也不会把任何论文标成核心必读。

## What to read first

| Rank | Paper | Role | Evidence grounding | Intent match | Reading priority | Intent match summary | Matched groups | Missing groups | Context warning | Why read now |
| ---: | --- | --- | --- | ---: | --- | --- | --- | --- | --- | --- |

## Important caveat

`strict_support` means the evidence sentence is grounded in the abstract. It does not by itself mean the paper is highly relevant.
A paper can have `strict_support` but still be background or peripheral if it misses required concept groups or has non-target context.

## Provider status

- openalex: not_attempted (0 papers returned)
- semantic_scholar: not_attempted (0 papers returned)

## How to narrow the next run

Use feedback such as 'exclude sodium batteries' or 'show more in situ characterization methods' to refine the next pass.
