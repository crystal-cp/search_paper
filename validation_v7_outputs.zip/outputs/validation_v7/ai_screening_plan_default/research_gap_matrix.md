# Research Gap Matrix

| gap_generation_status | reason | gap_key | gap_label | gap | evidence_or_reason | supporting_papers | why_gap_remains | possible_project_idea | suggested_next_searches | confidence | related_aspects |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| skipped | retrieval_not_performed | gap_generation_skipped | Research gap generation skipped | gap_generation_status=skipped | retrieval_not_performed |  | 本次只完成 query planning，未执行论文检索，因此不生成 research gaps。 |  |  | 0.00 |  |
