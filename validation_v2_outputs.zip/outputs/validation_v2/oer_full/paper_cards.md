# Paper Evidence Cards

## 1. Spin Effects in Chemisorption and Catalysis

- Year / venue / citations: 2023 | ACS Catalysis | 150
- DOI or URL: 10.1021/acscatal.2c06319
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.675, relevance=0.395, evidence=0.745
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate, OER
- Claim: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Evidence sentence: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Advanced Transition Metal‐Based OER Electrocatalysts: Current Status, Opportunities, and Challenges

- Year / venue / citations: 2021 | Small | 984
- DOI or URL: 10.1002/smll.202100129
- Decision: include
- Reading priority: read_later
- Recommended role: background
- Why relevant: score=0.668, relevance=0.409, evidence=0.709
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Evidence sentence: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 3. Spin polarization induced rapid reconstruction of transition metal oxide for efficient water electrolysis

- Year / venue / citations: 2025 | Chemical Science | 11
- DOI or URL: 10.1039/d5sc04336k
- Decision: maybe
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.657, relevance=0.414, evidence=0.745
- Domain decision: in_scope
- Covered aspects: materials_cases, OER
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: Although high-valent metal hydroxyl oxides formed in situ through electrochemical oxidation of the metal oxide matrix are key active sites for the oxygen evolution reaction (OER) in transition metal oxides, such a sluggish structural reconstruction largely hinders the electrocatalytic performance.
- Evidence sentence: Although high-valent metal hydroxyl oxides formed in situ through electrochemical oxidation of the metal oxide matrix are key active sites for the oxygen evolution reaction (OER) in transition metal oxides, such a sluggish structural reconstruction largely hinders the electrocatalytic performance.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 4. Beyond Volcano Top of Transition Metal‐Based Electrocatalysts Triggered by Spin State Modulation

- Year / venue / citations: 2025 | Advanced Functional Materials | 8
- DOI or URL: 10.1002/adfm.202520395
- Decision: include
- Reading priority: read_later
- Recommended role: evaluation
- Why relevant: score=0.656, relevance=0.437, evidence=0.782
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, controversy_debate
- Claim: Although modulating the spin state of transition metal (TM)‐based catalysts has emerged as a strategy to improve the sluggish kinetics of oxygen evolution reaction (OER), the quantitative correlation between spin state and OER activity remains elusive, especially at the experimental level.
- Evidence sentence: Although modulating the spin state of transition metal (TM)‐based catalysts has emerged as a strategy to improve the sluggish kinetics of oxygen evolution reaction (OER), the quantitative correlation between spin state and OER activity remains elusive, especially at the experimental level.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 5. Understanding the sulphur-oxygen exchange process of metal sulphides prior to oxygen evolution reaction

- Year / venue / citations: 2023 | Nature Communications | 310
- DOI or URL: 10.1038/s41467-023-37751-y
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.653, relevance=0.333, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, OER
- Missing aspects: review_background, methods_characterization, controversy_debate, surface spin state
- Claim: Abstract Dynamic reconstruction of metal sulphides during electrocatalytic oxygen evolution reaction (OER) has hampered the acquisition of legible evidence for comprehensively understanding the phase-transition mechanism and electrocatalytic activity origin.
- Evidence sentence: Abstract Dynamic reconstruction of metal sulphides during electrocatalytic oxygen evolution reaction (OER) has hampered the acquisition of legible evidence for comprehensively understanding the phase-transition mechanism and electrocatalytic activity origin.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 6. Spin-Modulated Oxygen Electrocatalysis

- Year / venue / citations: 2023 | Precision Chemistry | 108
- DOI or URL: 10.1021/prechem.3c00059
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.649, relevance=0.371, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, OER, surface spin state
- Missing aspects: methods_characterization, materials_cases, controversy_debate
- Claim: It is demonstrated that the spin states (low, intermediate, and high spin) of magnetic transition metal catalysts (TMCs) can directly affect the reaction barriers of OER/ORR by tailoring the bonding of oxygen intermediates with TMCs.
- Evidence sentence: It is demonstrated that the spin states (low, intermediate, and high spin) of magnetic transition metal catalysts (TMCs) can directly affect the reaction barriers of OER/ORR by tailoring the bonding of oxygen intermediates with TMCs.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 7. Triggered lattice-oxygen oxidation with active-site generation and self-termination of surface reconstruction during water oxidation

- Year / venue / citations: 2023 | Proceedings of the National Academy of Sciences | 45
- DOI or URL: 10.1073/pnas.2312224120
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.641, relevance=0.379, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, controversy_debate
- Claim: As OER progresses, the accumulation of oxygen vacancies and lattice-oxygen oxidation on the catalyst surface leads to the termination of Al 3+ leaching, thereby preventing further reconstruction.
- Evidence sentence: As OER progresses, the accumulation of oxygen vacancies and lattice-oxygen oxidation on the catalyst surface leads to the termination of Al 3+ leaching, thereby preventing further reconstruction.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 8. High‐Efficiency Oxygen Evolution Reaction: Controllable Reconstruction of Surface Interface

- Year / venue / citations: 2023 | Small | 84
- DOI or URL: 10.1002/smll.202304007
- Decision: include
- Reading priority: read_later
- Recommended role: background
- Why relevant: score=0.628, relevance=0.392, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, controversy_debate, OER, surface spin state
- Missing aspects: methods_characterization
- Claim: This review will provide some reference for surface controllable reconstruction of OER transition metal-based catalysts and reasonable development of ideal catalytic performance.
- Evidence sentence: This review will provide some reference for surface controllable reconstruction of OER transition metal-based catalysts and reasonable development of ideal catalytic performance.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 9. Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts

- Year / venue / citations: 2024 | Advanced Materials | 89
- DOI or URL: 10.1002/adma.202400572
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.625, relevance=0.330, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate
- Claim: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Evidence sentence: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 10. Engineering electrocatalytic activity in nanosized perovskite cobaltite through surface spin-state transition

- Year / venue / citations: 2016 | Nature Communications | 488
- DOI or URL: 10.1038/ncomms11510
- Decision: include
- Reading priority: read_later
- Recommended role: background
- Why relevant: score=0.624, relevance=0.430, evidence=0.745
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, surface spin state
- Missing aspects: review_background, theory_mechanism, controversy_debate, OER
- Claim: This enhancement is ascribed to the emergence of spin-state transition from low-spin to high-spin states for cobalt ions at the surface of the nanoparticles, leading to more active sites with increased reactivity.
- Evidence sentence: This enhancement is ascribed to the emergence of spin-state transition from low-spin to high-spin states for cobalt ions at the surface of the nanoparticles, leading to more active sites with increased reactivity.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 11. The electronic structure of transition metal oxides for oxygen evolution reaction

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 261
- DOI or URL: 10.1039/d1ta03732c
- Decision: include
- Reading priority: read_later
- Recommended role: background
- Why relevant: score=0.620, relevance=0.344, evidence=0.709
- Domain decision: in_scope
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Evidence sentence: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 12. Tuning α‐MnOOH Formation via Atomic‐Level Fe Introduction for Superior OER Performance

- Year / venue / citations: 2025 | Advanced Functional Materials | 63
- DOI or URL: 10.1002/adfm.202503360
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.618, relevance=0.333, evidence=0.709
- Domain decision: in_scope
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: Theoretical calculations also demonstrate that the effective active sites regulated in the representative catalyst of α‐MnOOH can reduce the energy barrier for a crucial step during the OER process (the *O to *OOH transition), thus significantly enhancing catalytic performance.
- Evidence sentence: Theoretical calculations also demonstrate that the effective active sites regulated in the representative catalyst of α‐MnOOH can reduce the energy barrier for a crucial step during the OER process (the *O to *OOH transition), thus significantly enhancing catalytic performance.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include
