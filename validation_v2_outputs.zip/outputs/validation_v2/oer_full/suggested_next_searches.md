# Suggested Next Searches

| query | reason | source |
| --- | --- | --- |
| OER "surface spin state" "span-grounded" "evidence verification" | Investigate undercovered gap: Evidence verification is undercovered | research_gap_matrix |
| OER "surface spin state" | Pilot search flagged drift for query: "transition metal oxide" OER | query_pilot_diagnostics |
| OER "surface spin state" oxygen oer metal | Expand around keywords from currently included papers. | included_paper_keywords |
