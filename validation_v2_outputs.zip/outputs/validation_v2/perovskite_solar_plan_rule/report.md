# Literature Screening Decision Report

## Research Question

我想了解钙钛矿太阳能电池中缺陷钝化为什么重要，以及有哪些实验方法可以表征缺陷态和载流子复合。

## Question Preprocessing

Planning question: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.

Translated question: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.

## How the system corrected the user’s question

- User original wording: 我想了解钙钛矿太阳能电池中缺陷钝化为什么重要，以及有哪些实验方法可以表征缺陷态和载流子复合。
- Expert rewritten question: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.
- Downweighted user terms: importance, significance
- Expert concepts added: defect passivation, defect states, carrier recombination, perovskite solar cell, characterization

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording:
  - background or review papers
  - evidence papers that demonstrate why the effect matters
  - application or device-motivation papers
- Selected interpretation: Not explicitly selected.
- Why this interpretation: Not generated in this run.
- Ambiguity points:
  - The motivation word 'importance/significance' may ask for background, evidence papers, application motivation, or device relevance.
- Needs user confirmation:
  - Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Unsafe or overbroad assumptions avoided:
  - Do not collapse 'importance' into only review/survey/tutorial queries.
- User words not mechanically used as hard query terms: importance, significance

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| defect passivation | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| defect states | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| carrier recombination | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| perovskite solar cell | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |

Downweighted terms: importance, significance

Optional or uncertain concepts: perovskite solar cell, characterization

Needs user confirmation: Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Assumptions needing confirmation or verification:
  - No domain-specific intent repair rules matched.
  - Do not treat broad motivation words as hard retrieval requirements.
  - Treat 'importance' as a request for background plus evidence and application/device motivation, not only review articles.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.
  - Do not collapse 'importance' into only review/survey/tutorial queries.

## What the System Thinks the User Is Looking For

- Refined question: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Inclusion criteria: experimental, defect passivation, defect states, carrier recombination, characterization
- Exclusion criteria: 
- Required aspects: experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Preferred paper types: review, survey, tutorial, methodological paper
- Time window: no strict time window
- Success definition: A small set of background papers plus clear concepts.

## Search Contract

- Domain: general_science
- Positive domains: science
- Negative domains: 
- Must include concepts: defect passivation, defect states, carrier recombination
- Must exclude concepts: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, defect passivation, defect states, carrier recombination
- Field whitelist: 
- Field blacklist: 

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: defect passivation, defect states, carrier recombination, perovskite solar cell, characterization
- Must terms: defect passivation, defect states, carrier recombination
- Optional terms: perovskite solar cell, characterization
- Exclude terms: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, defect passivation, defect states, carrier recombination
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'general_science', 'intent_domain': 'general_science', 'must_term_groups': [['defect passivation', 'defect states', 'carrier recombination'], ['defect passivation', 'defect states', 'carrier recombination']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['defect passivation', 'defect states', 'carrier recombination'], 'source': 'expert_intent', 'required': True}, {'group_name': 'optional_high_confidence', 'operator': 'OR', 'terms': ['perovskite solar cell', 'characterization'], 'source': 'expert_intent', 'required': False}, {'group_name': 'core_object_group', 'operator': 'OR', 'terms': ['defect passivation', 'defect states', 'carrier recombination'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'domain_context_group', 'operator': 'OR', 'terms': ['perovskite solar cell'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'process_or_property_group', 'operator': 'OR', 'terms': ['defect', 'passivation', 'recombination'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['characterization'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'material_or_case_group', 'operator': 'OR', 'terms': ['perovskite solar cell'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'failure_or_limitation_group', 'operator': 'OR', 'terms': ['defect passivation', 'defect states', 'defect'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': ['perovskite solar cell'], 'intent_methods': ['characterization'], 'intent_repair_used': True, 'structured_concepts': [{'term': 'importance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'significance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'defect passivation', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'defect states', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'carrier recombination', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'perovskite solar cell', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想了解钙钛矿太阳能电池中缺陷钝化为什么重要，以及有哪些实验方法可以表征缺陷态和载流子复合。
- Refined question: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Domain: general_science
- Must include concepts: defect passivation, defect states, carrier recombination
- Must exclude concepts: 
- Core terms: defect passivation, defect states, carrier recombination, perovskite solar cell, characterization
- Expert rewrite: Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.
- Downweighted user terms: importance, significance

## 2. Concept decomposition

- Domain: general_science
- Central question: 我想了解钙钛矿太阳能电池中缺陷钝化为什么重要，以及有哪些实验方法可以表征缺陷态和载流子复合。 Find papers about defect passivation, defect states, carrier recombination, perovskite solar cell.
- core_topic: concepts=defect passivation, defect states, carrier recombination, defect, passivation; methods=characterization; materials=perovskite solar cell
- characterization_methods: concepts=defect passivation, defect states, carrier recombination, defect, passivation; methods=characterization; materials=perovskite solar cell
- materials_or_cases: concepts=defect passivation, defect states, carrier recombination, defect, passivation; methods=characterization; materials=perovskite solar cell
- failure_or_limitation: concepts=defect passivation, defect states, carrier recombination, defect, passivation; methods=characterization; materials=perovskite solar cell

## 3. Search lenses and query families

- Query families generated: 4
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" review \| semantic_scholar: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" review
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" characterization \| semantic_scholar: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" charac
- materials_or_cases (lens=materials_or_cases): find representative materials, systems, benchmarks, or case studies; sample queries=openalex: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" "case study" \| semantic_scholar: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" "case stud
- failure_or_limitation (lens=failure_or_limitation): find failure modes, degradation, limitations, or boundary conditions; sample queries=openalex: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" "failure mechanism" \| semantic_scholar: "defect passivation" "defect states" "perovskite solar cell"; "defect passivation" "defect states" "perovskite solar cell" "fa

## 4. Screening and inclusion criteria

- Inclusion criteria: experimental, defect passivation, defect states, carrier recombination, characterization
- Exclusion criteria: 
- Required aspects: experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Contract inclusion criteria: experimental, defect passivation, defect states, carrier recombination, characterization
- Contract exclusion criteria: 

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 0 paper(s)
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 0 paper(s)
- review_background: 0 paper(s)

## 6. Research lineage

Not generated in this run.
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Evidence verification is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Evaluation protocol is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Evidence verification is undercovered: 
  - Evaluation protocol is undercovered: 
- Lens methods to audit: characterization
- Lens materials to audit: perovskite solar cell
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- "defect passivation" "defect states" "carrier recombination" "span-grounded" "evidence verification"
- "defect passivation" "defect states" "carrier recombination" "benchmark" "evaluation protocol"

## 10. Verified vs uncertain findings

- Verified:
  - No strict or span-validated findings were available.
- Uncertain:
  - No uncertain findings were identified.
- Evidence functions observed: 

## Planned Queries

- "defect passivation" "defect states" "perovskite solar cell"
- "defect passivation" "defect states" "perovskite solar cell" review
- "defect passivation" "defect states" "perovskite solar cell" background
- "defect passivation" "defect states" "perovskite solar cell" "carrier recombination"
- "defect passivation" "defect states" "perovskite solar cell" defect
- "defect passivation" "defect states" "perovskite solar cell" characterization
- "defect passivation" "defect states" "perovskite solar cell" "experimental characterization"
- "defect passivation" "defect states" "perovskite solar cell" "carrier recombination" characterization
- "defect passivation" "defect states" "perovskite solar cell" defect characterization
- "defect passivation" "defect states" "perovskite solar cell" "case study"
- "defect passivation" "defect states" "perovskite solar cell" "representative materials"
- "defect passivation" "defect states" "perovskite solar cell" "failure mechanism"
- "defect passivation" "defect states" "perovskite solar cell" "limitation degradation"
- "defect passivation" "defect states" "perovskite solar cell" "carrier recombination" limitation
- "defect passivation" "defect states" "perovskite solar cell" defect limitation

## Domain Guardrails

- In scope: 0
- Borderline: 0
- Out of scope: 0

- No papers were demoted by domain guardrails.

## Query Pilot Diagnostics

- Pilot search was not run for this report.

## Query Repairs Applied

- Auto repair applied: False

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
|  |  |  |  | static_query_quality_repair |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 0
- Merged paper count: 0
- Duplicate count: 0
- Counts by provider: {'openalex': 0, 'semantic_scholar': 0}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 0
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 0
- Records identified by Semantic Scholar: 0
- Duplicate records removed: 0
- Records with missing abstracts: 0
- Records screened: 0
- Records included: 0
- Records maybe: 0
- Records excluded: 0
- Out-of-domain records: 0
- Included in top ranked results: 0
- Excluded or low confidence: 0
- Common exclusion reasons: {}

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

- Strict supported count: 0
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 0.000
- Strict support rate: 0.000
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.000

## Scoring Formula

`final_score = 0.40 * relevance_score + 0.25 * evidence_score + 0.15 * recency_score + 0.15 * quality_score + 0.05 * diversity_score + human_feedback_adjustment + preference_adjustment, then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | --- |

## Included Papers

- No papers were automatically marked include.

## Maybe / Needs Human Inspection

- No papers were marked maybe.

## Excluded Papers And Reasons

- No papers were automatically excluded.

## Common Exclusion Reasons

- No exclusion reasons were recorded.

## Method Comparison Matrix

- No method comparison rows were generated.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Evidence verification is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Span-grounded verification for abstract-level evidence chains. | review_background: review; background; overview; introduction |
| Evaluation protocol is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Benchmarking and evaluation protocol for literature screening agents. | materials_cases: material; system; case study; benchmark |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| "defect passivation" "defect states" "carrier recombination" "span-grounded" "evidence verification" | Investigate undercovered gap: Evidence verification is undercovered | research_gap_matrix |
| "defect passivation" "defect states" "carrier recombination" "benchmark" "evaluation protocol" | Investigate undercovered gap: Evaluation protocol is undercovered | research_gap_matrix |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

- No required aspects were classified.

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 0 papers
- recent_frontier: 0 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 0 papers
- background_or_survey: 0 papers
- peripheral: 0 papers
- excluded_or_low_confidence: 0 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.000
- Unsupported claim rate: 0.000
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: overview
- Planner: 15 planned query strings.
- Retriever: 0 raw records, 0 merged records.
- Domain guardrail: 0 in_scope, 0 borderline, 0 out_of_scope.
- Screening decision agent: 0 include, 0 maybe, 0 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
