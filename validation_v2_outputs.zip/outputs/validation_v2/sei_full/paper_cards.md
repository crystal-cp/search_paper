# Paper Evidence Cards

## 1. Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook

- Year / venue / citations: 2023 | Advanced Energy Materials | 729
- DOI or URL: 10.1002/aenm.202203307
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.779, relevance=0.582, evidence=0.818
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI).
- Evidence sentence: In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries

- Year / venue / citations: 2018 | npj Computational Materials | 1594
- DOI or URL: 10.1038/s41524-018-0064-0
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.713, relevance=0.598, evidence=0.745
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes.
- Evidence sentence: Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 3. Capturing the swelling of solid-electrolyte interphase in lithium metal batteries

- Year / venue / citations: 2022 | Science | 446
- DOI or URL: 10.1126/science.abi8703
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.711, relevance=0.472, evidence=0.782
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, theory_mechanism, failure_limitation
- Claim: We report substantial swelling of the solid-electrolyte interphase (SEI) on lithium metal anode in various electrolytes.
- Evidence sentence: We report substantial swelling of the solid-electrolyte interphase (SEI) on lithium metal anode in various electrolytes.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 4. A Perspective on the Molecular Modeling of Electrolyte Decomposition Reactions for Solid Electrolyte Interphase Growth in Lithium‐Ion Batteries

- Year / venue / citations: 2024 | Advanced Functional Materials | 36
- DOI or URL: 10.1002/adfm.202313188
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.708, relevance=0.503, evidence=0.855
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, failure_limitation
- Claim: The solid electrolyte interphase (SEI) is a thin heterogeneous layer formed at the anode/electrolyte interface in lithium‐ion batteries as a consequence of the reduction of the electrolyte.
- Evidence sentence: The solid electrolyte interphase (SEI) is a thin heterogeneous layer formed at the anode/electrolyte interface in lithium‐ion batteries as a consequence of the reduction of the electrolyte.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 5. Lignin‐derived hard carbon anode with a robust solid electrolyte interphase for boosted sodium storage performance

- Year / venue / citations: 2024 | Carbon Energy | 80
- DOI or URL: 10.1002/cey2.538
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.705, relevance=0.471, evidence=0.782
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background
- Claim: In addition, the solid electrolyte interphase (SEI) is subjected to continuous rupture during battery cycling, leading to fast capacity decay.
- Evidence sentence: In addition, the solid electrolyte interphase (SEI) is subjected to continuous rupture during battery cycling, leading to fast capacity decay.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 6. Thermal Decomposition of the Solid Electrolyte Interphase (SEI) on Silicon Electrodes for Lithium Ion Batteries

- Year / venue / citations: 2017 | Chemistry of Materials | 174
- DOI or URL: 10.1021/acs.chemmater.7b00454
- Decision: include
- Reading priority: read_later
- Recommended role: motivation
- Why relevant: score=0.696, relevance=0.544, evidence=0.818
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, failure_limitation
- Claim: Thermal behavior of the solid electrolyte interphase (SEI) on a silicon electrode for lithium ion batteries has been investigated by TGA.
- Evidence sentence: Thermal behavior of the solid electrolyte interphase (SEI) on a silicon electrode for lithium ion batteries has been investigated by TGA.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 7. Transport of Ions, Molecules, and Electrons across the Solid Electrolyte Interphase: What Is Our Current Level of Understanding?

- Year / venue / citations: 2022 | Advanced Materials Interfaces | 41
- DOI or URL: 10.1002/admi.202101891
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.695, relevance=0.521, evidence=0.855
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: methods_characterization
- Claim: Abstract The solid electrolyte interphase (SEI) on the graphite particles of lithium‐ion battery anodes passivates the anode against electrolyte reduction due to electron transfer reactions, and a stable and well‐passivating SEI is an important prerequisite for a long cycle life of batteries.
- Evidence sentence: Abstract The solid electrolyte interphase (SEI) on the graphite particles of lithium‐ion battery anodes passivates the anode against electrolyte reduction due to electron transfer reactions, and a stable and well‐passivating SEI is an important prerequisite for a long cycle life of batteries.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 8. Lithium-Ion Batteries

- Year / venue / citations: 2004 | PUBLISHED BY IMPERIAL COLLEGE PRESS AND DISTRIBUTED BY WORLD SCIENTIFIC PUBLISHING CO. eBooks | 431
- DOI or URL: 10.1142/p291
- Decision: include
- Reading priority: read_later
- Recommended role: motivation
- Why relevant: score=0.685, relevance=0.529, evidence=0.891
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, failure_limitation
- Claim: SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interphase on Positive and Negative Electrodes for Lithium-Ion Batteries (Z-X Wang et al.) Scanning Probe Microscopy Analysis of the SEI Formation on Graphite Anodes (M Inaba & Z Ogumi) Theoretical Insights into the SEI Components and Formation Mechanism: Density Functional Theory Studies (Y-X Wang & P B Balbuena) Continuum and Statistical Mechanics-Based Models for Solid-Electrolyte Interphases in Lithium-Ion Batteries (H J Ploehn et al.) Development of New Anodes for Rechargeable Lithium Batteries and Their SEI Characterization by Raman and NEXAFS Spectroscopy (G Sandi) The Cathode-Electrolyte Interface in a Li-Ion Battery (K Edstrom et al.) Theoretical Studies on the Structure, Association of Solvent, and Solvation of Li Ion: Implications to SEI Layer Phenomena (Y-X Wang & P B Balbuena).
- Evidence sentence: SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interphase on Positive and Negative Electrodes for Lithium-Ion Batteries (Z-X Wang et al.) Scanning Probe Microscopy Analysis of the SEI Formation on Graphite Anodes (M Inaba & Z Ogumi) Theoretical Insights into the SEI Components and Formation Mechanism: Density Functional Theory Studies (Y-X Wang & P B Balbuena) Continuum and Statistical Mechanics-Based Models for Solid-Electrolyte Interphases in Lithium-Ion Batteries (H J Ploehn et al.) Development of New Anodes for Rechargeable Lithium Batteries and Their SEI Characterization by Raman and NEXAFS Spectroscopy (G Sandi) The Cathode-Electrolyte Interface in a Li-Ion Battery (K Edstrom et al.) Theoretical Studies on the Structure, Association of Solvent, and Solvation of Li Ion: Implications to SEI Layer Phenomena (Y-X Wang & P B Balbuena).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 9. Frontiers in Theoretical Analysis of Solid Electrolyte Interphase Formation Mechanism

- Year / venue / citations: 2021 | Advanced Materials | 143
- DOI or URL: 10.1002/adma.202100574
- Decision: include
- Reading priority: read_later
- Recommended role: motivation
- Why relevant: score=0.685, relevance=0.468, evidence=0.818
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: failure_limitation
- Claim: Solid electrolyte interphase (SEI) is an ion conductive yet electron-insulating layer on battery electrodes, which is formed by the reductive decomposition of electrolytes during the initial charge.
- Evidence sentence: Solid electrolyte interphase (SEI) is an ion conductive yet electron-insulating layer on battery electrodes, which is formed by the reductive decomposition of electrolytes during the initial charge.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 10. Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries

- Year / venue / citations: 2019 | Nanoscale | 183
- DOI or URL: 10.1039/c9nr05748j
- Decision: include
- Reading priority: read_later
- Recommended role: motivation
- Why relevant: score=0.682, relevance=0.523, evidence=0.855
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: 
- Claim: The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition.
- Evidence sentence: The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 11. Dynamics and morphology of solid electrolyte interphase (SEI)

- Year / venue / citations: 2016 | Physical Chemistry Chemical Physics | 105
- DOI or URL: 10.1039/c6cp02816k
- Decision: include
- Reading priority: read_later
- Recommended role: motivation
- Why relevant: score=0.681, relevance=0.506, evidence=0.855
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI
- Missing aspects: review_background, failure_limitation
- Claim: We develop a novel theory for the continuous electrochemical formation of porous films to study the solid electrolyte interphase (SEI) on lithium ion battery anodes.
- Evidence sentence: We develop a novel theory for the continuous electrochemical formation of porous films to study the solid electrolyte interphase (SEI) on lithium ion battery anodes.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 12. Eliminating Graphite Exfoliation with an Artificial Solid Electrolyte Interphase for Stable Lithium‐Ion Batteries

- Year / venue / citations: 2022 | Small | 85
- DOI or URL: 10.1002/smll.202107460
- Decision: include
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.681, relevance=0.487, evidence=0.745
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI
- Missing aspects: review_background, theory_mechanism
- Claim: Using different characterization techniques, severe graphite exfoliation, and continuously increasing solid electrolyte interphase (SEI) are demonstrated as reasons for the failure of G samples.
- Evidence sentence: Using different characterization techniques, severe graphite exfoliation, and continuously increasing solid electrolyte interphase (SEI) are demonstrated as reasons for the failure of G samples.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include
