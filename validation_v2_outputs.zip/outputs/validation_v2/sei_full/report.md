# Literature Screening Decision Report

## Research Question

我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。

## Question Preprocessing

Planning question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.

Translated question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.

## How the system corrected the user’s question

- User original wording: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。
- Expert rewritten question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Downweighted user terms: importance, significance
- Expert concepts added: solid electrolyte interphase, SEI, representative material systems, theoretical background, ex situ, in situ, SEI SEI, failure mechanism, lithium-ion battery, interface, characterization

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording:
  - direct citation or same-author related papers
  - topic-related papers
  - method-related papers
  - application-related papers
  - theory-lineage related papers
  - background or review papers
  - evidence papers that demonstrate why the effect matters
  - application or device-motivation papers
- Selected interpretation: topic + method + theory-lineage related papers
- Why this interpretation: The question mentions research concepts and probe goals, but no verified citation relation; topical, methodological, and theory-lineage relevance is the safest default.
- Ambiguity points:
  - The phrase 'related papers' is ambiguous: it may mean direct citation, same author, topical similarity, method overlap, application relevance, or theory lineage.
  - The motivation word 'importance/significance' may ask for background, evidence papers, application motivation, or device relevance.
- Needs user confirmation:
  - Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance.
  - Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Unsafe or overbroad assumptions avoided:
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.
  - Do not collapse 'importance' into only review/survey/tutorial queries.
- User words not mechanically used as hard query terms: importance, significance

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| solid electrolyte interphase | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| SEI | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| lithium-ion battery | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| interface | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| composition | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| structure | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| evolution | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| failure mechanism | mechanism | user_text | optional | yes | User asks for theory or mechanism evidence. |
| representative material systems | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| theoretical background | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| ex situ | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| in situ | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| SEI SEI | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |

Downweighted terms: importance, significance

Optional or uncertain concepts: lithium-ion battery, interface, composition, structure, evolution, characterization, failure mechanism, representative material systems, theoretical background, ex situ, in situ, SEI SEI

Needs user confirmation: Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance., Confirm whether the user wants broad background, evidence papers, application motivation, or all three.
- Assumptions needing confirmation or verification:
  - No domain-specific intent repair rules matched.
  - Do not treat broad motivation words as hard retrieval requirements.
  - Assume 'related papers' means topic + method + theory-lineage relevance unless the user asks for citation or author-only expansion.
  - Treat 'importance' as a request for background plus evidence and application/device motivation, not only review articles.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.
  - Do not collapse 'importance' into only review/survey/tutorial queries.

## What the System Thinks the User Is Looking For

- Refined question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, characterization
- Exclusion criteria: 
- Required aspects: interface, materials, experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Preferred paper types: review, survey, tutorial, methodological paper, theoretical paper
- Time window: no strict time window
- Success definition: A small set of background papers plus clear concepts.

## Search Contract

- Domain: general_science
- Positive domains: science
- Negative domains: 
- Must include concepts: solid electrolyte interphase, SEI
- Must exclude concepts: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, solid electrolyte interphase, SEI
- Field whitelist: 
- Field blacklist: 

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: solid electrolyte interphase, SEI, lithium-ion battery, interface, composition, structure, evolution, characterization, failure mechanism, representative material systems, theoretical background, ex situ, in situ, SEI SEI
- Must terms: solid electrolyte interphase, SEI
- Optional terms: lithium-ion battery, interface, composition, structure, evolution, characterization, failure mechanism, representative material systems, theoretical background, ex situ
- Exclude terms: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, failure_limitation: failure; limitation; degradation; aging; stability, solid electrolyte interphase, SEI
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'general_science', 'intent_domain': 'general_science', 'must_term_groups': [['solid electrolyte interphase', 'SEI'], ['solid electrolyte interphase', 'SEI']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['solid electrolyte interphase', 'SEI'], 'source': 'expert_intent', 'required': True}, {'group_name': 'optional_high_confidence', 'operator': 'OR', 'terms': ['lithium-ion battery', 'interface', 'composition', 'structure', 'evolution', 'characterization', 'failure mechanism', 'representative material systems', 'theoretical background', 'ex situ', 'in situ', 'SEI SEI'], 'source': 'expert_intent', 'required': False}, {'group_name': 'core_object_group', 'operator': 'OR', 'terms': ['solid electrolyte interphase', 'SEI'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'domain_context_group', 'operator': 'OR', 'terms': ['lithium-ion battery', 'interface', 'electrolyte', 'battery'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'process_or_property_group', 'operator': 'OR', 'terms': ['composition', 'structure', 'evolution'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['characterization'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'mechanism_group', 'operator': 'OR', 'terms': ['failure mechanism'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'material_or_case_group', 'operator': 'OR', 'terms': ['lithium-ion battery', 'interface'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'failure_or_limitation_group', 'operator': 'OR', 'terms': ['failure mechanism'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': ['lithium-ion battery', 'interface'], 'intent_methods': ['characterization'], 'intent_repair_used': True, 'structured_concepts': [{'term': 'importance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'significance', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'solid electrolyte interphase', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'SEI', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'lithium-ion battery', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'interface', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'composition', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'structure', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'evolution', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'failure mechanism', 'category': 'mechanism', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for theory or mechanism evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'representative material systems', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'theoretical background', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'ex situ', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'in situ', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'SEI SEI', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。
- Refined question: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Domain: general_science
- Must include concepts: solid electrolyte interphase, SEI
- Must exclude concepts: 
- Core terms: solid electrolyte interphase, SEI, lithium-ion battery, interface, composition, structure, evolution, characterization
- Expert rewrite: Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- Downweighted user terms: importance, significance

## 2. Concept decomposition

- Domain: general_science
- Central question: 我想了解锂离子电池中 SEI 界面为什么重要，以及有哪些实验方法可以表征 SEI 的组成、结构和演化。最好能找到理论背景、原位/非原位表征方法、典型材料体系和失效机制相关论文。 Find papers about solid electrolyte interphase, SEI, lithium-ion battery, interface.
- core_topic: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=characterization; materials=lithium-ion battery, interface, electrolyte, battery
- theory_mechanism: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=characterization; materials=lithium-ion battery, interface, electrolyte, battery
- characterization_methods: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=characterization; materials=lithium-ion battery, interface, electrolyte, battery
- materials_or_cases: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=characterization; materials=lithium-ion battery, interface, electrolyte, battery
- failure_or_limitation: concepts=solid electrolyte interphase, SEI, composition, structure, evolution; methods=characterization; materials=lithium-ion battery, interface, electrolyte, battery

## 3. Search lenses and query families

- Query families generated: 5
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" interface review \| semantic_scholar: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" in
- theory_mechanism (lens=theory_mechanism): find theory, mechanism, model, or causal-relation papers; sample queries=openalex: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" interface mechanism \| semantic_scholar: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery"
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" characterization \| semantic_scholar: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" ch
- materials_or_cases (lens=materials_or_cases): find representative materials, systems, benchmarks, or case studies; sample queries=openalex: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" interface electrolyte "case study" \| semantic_scholar: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithi
- failure_or_limitation (lens=failure_or_limitation): find failure modes, degradation, limitations, or boundary conditions; sample queries=openalex: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-ion battery" interface "failure mechanism" \| semantic_scholar: "solid electrolyte interphase" SEI "lithium-ion battery" interface; "solid electrolyte interphase" SEI "lithium-io

## 4. Screening and inclusion criteria

- Inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, characterization
- Exclusion criteria: 
- Required aspects: interface, materials, experimental, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Contract inclusion criteria: interface materials experimental theoretical mechanism sei, solid electrolyte interphase, SEI, representative material systems, theoretical background, failure mechanism, characterization
- Contract exclusion criteria: 
- Decision counts: {'include': 53, 'maybe': 36, 'exclude': 13}

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 1 paper(s)
  - Spatiotemporal Changes of the Solid Electrolyte Interphase in Lithium‐Ion Batteries Detected by Scanning Electrochemical Microscopy (1f6c9b4e8e193ab7): experimental_proof: matched imaging, direct_probe_method: matched tem
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 2 paper(s)
  - Synergetic Effects of Inorganic Components in Solid Electrolyte Interphase on High Cycle Efficiency of Lithium Ion Batteries (9bf579b6c32876d8): limitation_or_challenge: matched leakage, retrieval_lane: linked query family/lens recorded as provenance only
  - First-Principles Analysis of Defect Thermodynamics and Ion Transport in Inorganic SEI Compounds: LiF and NaF (457c25c7fd4ed1e3): limitation_or_challenge: matched defects, retrieval_lane: linked query family/lens recorded as provenance only
- review_background: 39 paper(s)
  - Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries (3646ddf16ae9a764): review_background: matched review, overview, retrieval_lane: linked query family/lens recorded as provenance only
  - 30 Years of Lithium‐Ion Batteries (9996facd4d50a226): direct_probe_method: matched tem, review_background: matched review
  - Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook (ac551ae01b662e6a): direct_probe_method: matched tem, stem, review_background: matched review
  - Materials for lithium-ion battery safety (c6d46685e1388c38): direct_probe_method: matched tem, stem, review_background: matched review

## 6. Research lineage

- 1998: An Advanced Tool for the Selection of Electrolyte Components for Rechargeable Lithium Batteries (material_case); citation relation not verified
- 2001: Studies on the Anode/Electrolyte Interfacein Lithium Ion Batteries (role not generated); citation relation not verified
- 2004: Lithium-Ion Batteries (role not generated); citation relation not verified
- 2004: A Self-Assembled Breathing Interface for All-Solid-State Ceramic Lithium Batteries (role not generated); citation relation not verified
- 2005: A new look at the solid electrolyte interphase on graphite anodes in Li-ion batteries (role not generated); citation relation not verified
- 2008: Study of the Interface Between Li[sub 4]Ti[sub 5]O[sub 12] Electrodes and Standard Electrolyte Solutions in 0.0–0.5 V (role not generated); citation relation not verified
- 2009: The Solid Electrolyte Interphase – The Most Important and the Least Understood Solid Electrolyte in Rechargeable Li Batteries (role not generated); citation relation not verified
- 2010: Cycling degradation of an automotive LiFePO4 lithium-ion battery (role not generated); citation relation not verified
- 2011: Modeling detailed chemistry and transport for solid-electrolyte-interface (SEI) films in Li–ion batteries (role not generated); citation relation not verified
- 2013: An Artificial Solid Electrolyte Interphase Enables the Use of a LiNi<sub>0.5</sub> Mn<sub>1.5</sub> O<sub>4</sub> 5 V Cathode with Conventional Electrolytes (review_background); citation relation not verified
- 2013: Evaluating the performance of nanostructured materials as lithium-ion battery electrodes (review_background); citation relation not verified
- 2014: Role of Lithium Salt on Solid Electrolyte Interface (SEI) Formation and Structure in Lithium Ion Batteries (direct_probe_method); citation relation not verified
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Evidence verification is undercovered: 68 signal(s) suggest this aspect is undercovered across 102 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Evidence verification is undercovered: 
- Lens methods to audit: characterization
- Lens materials to audit: lithium-ion battery, interface, electrolyte, battery
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- "solid electrolyte interphase" SEI "span-grounded" "evidence verification"
- "solid electrolyte interphase" SEI
- "solid electrolyte interphase" SEI electrolyte solid lithium

## 10. Verified vs uncertain findings

- Verified:
  - Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook: strict_support; span=exact
  - Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries: strict_support; span=exact
  - Capturing the swelling of solid-electrolyte interphase in lithium metal batteries: strict_support; span=exact
  - A Perspective on the Molecular Modeling of Electrolyte Decomposition Reactions for Solid Electrolyte Interphase Growth in Lithium‐Ion Batteries: strict_support; span=exact
  - Lignin‐derived hard carbon anode with a robust solid electrolyte interphase for boosted sodium storage performance: strict_support; span=exact
  - Thermal Decomposition of the Solid Electrolyte Interphase (SEI) on Silicon Electrodes for Lithium Ion Batteries: strict_support; span=exact
  - Transport of Ions, Molecules, and Electrons across the Solid Electrolyte Interphase: What Is Our Current Level of Understanding?: strict_support; span=exact
  - Lithium-Ion Batteries: strict_support; span=exact
- Uncertain:
  - Electrolyte engineering for highly inorganic solid electrolyte interphase in high-performance lithium metal batteries: missing abstract; needs further verification
  - Direct in situ measurements of electrical properties of solid–electrolyte interphase on lithium metal anodes: missing abstract; needs further verification
  - Real-time mass spectrometric characterization of the solid–electrolyte interphase of a lithium-ion battery: missing abstract; needs further verification
  - Highly adaptable SEI/CEI interfacial layers enabling remarkable performance of high-nickel solid-state batteries: missing abstract; needs further verification
  - Review on multi-scale models of solid-electrolyte interphase formation: missing abstract; needs further verification
  - Understanding solid electrolyte interphases: Advanced characterization techniques and theoretical simulations: missing abstract; needs further verification
  - A new look at the solid electrolyte interphase on graphite anodes in Li-ion batteries: missing abstract; needs further verification
  - Modeling detailed chemistry and transport for solid-electrolyte-interface (SEI) films in Li–ion batteries: missing abstract; needs further verification
- Evidence functions observed: review_background, unknown, reports_experiment, defines_concept, reports_limitation, predicts_effect, directly_images_signal

## Planned Queries

- "solid electrolyte interphase" SEI "lithium-ion battery" interface
- "solid electrolyte interphase" SEI "lithium-ion battery" interface review
- "solid electrolyte interphase" SEI "lithium-ion battery" interface background
- "solid electrolyte interphase" SEI "lithium-ion battery" interface composition
- "solid electrolyte interphase" SEI "lithium-ion battery" interface structure
- "solid electrolyte interphase" SEI "lithium-ion battery" interface mechanism
- "solid electrolyte interphase" SEI "lithium-ion battery" interface theory
- "solid electrolyte interphase" SEI "lithium-ion battery" characterization
- "solid electrolyte interphase" SEI "lithium-ion battery" "experimental characterization"
- "solid electrolyte interphase" SEI "lithium-ion battery" composition characterization
- "solid electrolyte interphase" SEI "lithium-ion battery" structure characterization
- "solid electrolyte interphase" SEI "lithium-ion battery" interface electrolyte "case study"
- "solid electrolyte interphase" SEI "lithium-ion battery" interface electrolyte "representative materials"
- "solid electrolyte interphase" SEI "lithium-ion battery" interface "failure mechanism"
- "solid electrolyte interphase" SEI "lithium-ion battery" interface "limitation degradation"
- "solid electrolyte interphase" SEI "lithium-ion battery" interface composition limitation
- "solid electrolyte interphase" SEI "lithium-ion battery" interface structure limitation

## Domain Guardrails

- In scope: 68
- Borderline: 33
- Out of scope: 1

| Rank | Decision | Penalty | Domain score | Paper | Reason |
| ---: | --- | ---: | ---: | --- | --- |
| 63 | borderline | 0.7 | 0.0625 | Lithium ion battery degradation: what you need to know | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 64 | borderline | 0.7 | 0.0625 | Review—“Knees” in Lithium-Ion Battery Aging Trajectories | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 65 | borderline | 0.7 | 0.0625 | Advances and challenges in thermal runaway modeling of lithium-ion batteries | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 66 | borderline | 0.7 | 0.0625 | Low‐temperature performance of Na‐ion batteries | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 67 | borderline | 0.7 | 0.0625 | Review on the Experimental Characterization of Fracture in Active Material for Lithium-Ion Batteries | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 68 | borderline | 0.7 | 0.0625 | Perspectives for next generation lithium-ion battery cathode materials | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 69 | borderline | 0.7 | 0.0625 | Risk management over the life cycle of lithium-ion batteries in electric vehicles | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |
| 70 | borderline | 0.7 | 0.0625 | Liquid electrolyte development for low-temperature lithium-ion batteries | Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. |

Common off-topic reasons:
- Missing some required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. (33)
- Insufficient domain evidence; missing required concept(s): any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI, any of: solid electrolyte interphase OR SEI. (1)

## Query Pilot Diagnostics

- Pilot max per query: 5
- Pilot records: 26
- Mean off-topic rate: 0.0615
- Recommendation counts: {'keep': 22, 'repair': 4}
- Detected drift counts: {}

| Provider | Stage | Recommendation | Off-topic rate | Query | Drift |
| --- | --- | --- | ---: | --- | --- |
| openalex | openalex_keyword | keep | 0.0 | "solid electrolyte interphase" |  |
| openalex | openalex_semantic | keep | 0.0 | "solid electrolyte interphase" |  |
| openalex | openalex_keyword | repair | 0.4 | "lithium-ion battery" SEI |  |
| openalex | openalex_semantic | keep | 0.0 | "lithium-ion battery" SEI |  |
| openalex | openalex_keyword | keep | 0.0 | interface SEI |  |
| openalex | openalex_semantic | keep | 0.0 | interface SEI |  |
| openalex | openalex_keyword | keep | 0.0 | characterization SEI |  |
| openalex | openalex_semantic | repair | 0.4 | characterization SEI |  |
| openalex | openalex_keyword | keep | 0.2 | SEI solid electrolyte interphase representative material systems |  |
| openalex | openalex_semantic | keep | 0.0 | SEI solid electrolyte interphase representative material systems |  |
| openalex | openalex_keyword | keep | 0.0 | SEI "solid electrolyte interphase" |  |
| openalex | openalex_semantic | keep | 0.0 | SEI "solid electrolyte interphase" |  |

## Query Repairs Applied

- Auto repair applied: True

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
| openalex | repair | "lithium-ion battery" SEI | "lithium-ion battery" SEI "solid electrolyte interphase" | Pilot search estimated off-topic rate 0.4; detected drift: high off-topic rate. |
| openalex | repair | characterization SEI | characterization SEI "solid electrolyte interphase" | Pilot search estimated off-topic rate 0.4; detected drift: high off-topic rate. |
| openalex | repair | SEI "lithium-ion battery" | SEI "lithium-ion battery" "solid electrolyte interphase" | Pilot search estimated off-topic rate 0.4; detected drift: high off-topic rate. |
| semantic_scholar | repair | "lithium-ion battery" SEI | "lithium-ion battery" SEI +"solid electrolyte interphase" | Pilot search estimated off-topic rate 0.0; detected drift: high off-topic rate. |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 340
- Merged paper count: 102
- Duplicate count: 238
- Counts by provider: {'openalex': 330, 'semantic_scholar': 10}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 340
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 330
- Records identified by Semantic Scholar: 10
- Duplicate records removed: 238
- Records with missing abstracts: 20
- Records screened: 102
- Records included: 53
- Records maybe: 36
- Records excluded: 13
- Out-of-domain records: 1
- Included in top ranked results: 10
- Excluded or low confidence: 20
- Common exclusion reasons: {'missing_required_concept': 95, 'off_topic_domain': 24, 'missing_abstract': 20, 'low_metadata_quality': 1}

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

- Strict supported count: 82
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 1.000
- Strict support rate: 0.804
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.556

## Scoring Formula

`final_score = 0.40 * relevance_score + 0.25 * evidence_score + 0.15 * recency_score + 0.15 * quality_score + 0.05 * diversity_score + human_feedback_adjustment + preference_adjustment, then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | --- |
| 1 | include | 0.779 | in_scope | 2023 | Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook | Advanced Energy Materials | 10.1002/aenm.202203307 |
| 2 | include | 0.713 | in_scope | 2018 | Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries | npj Computational Materials | 10.1038/s41524-018-0064-0 |
| 3 | include | 0.711 | in_scope | 2022 | Capturing the swelling of solid-electrolyte interphase in lithium metal batteries | Science | 10.1126/science.abi8703 |
| 4 | include | 0.708 | in_scope | 2024 | A Perspective on the Molecular Modeling of Electrolyte Decomposition Reactions for Solid Electrolyte Interphase Growth in Lithium‐Ion Batteries | Advanced Functional Materials | 10.1002/adfm.202313188 |
| 5 | include | 0.705 | in_scope | 2024 | Lignin‐derived hard carbon anode with a robust solid electrolyte interphase for boosted sodium storage performance | Carbon Energy | 10.1002/cey2.538 |
| 6 | include | 0.696 | in_scope | 2017 | Thermal Decomposition of the Solid Electrolyte Interphase (SEI) on Silicon Electrodes for Lithium Ion Batteries | Chemistry of Materials | 10.1021/acs.chemmater.7b00454 |
| 7 | include | 0.695 | in_scope | 2022 | Transport of Ions, Molecules, and Electrons across the Solid Electrolyte Interphase: What Is Our Current Level of Understanding? | Advanced Materials Interfaces | 10.1002/admi.202101891 |
| 8 | include | 0.685 | in_scope | 2004 | Lithium-Ion Batteries | PUBLISHED BY IMPERIAL COLLEGE PRESS AND DISTRIBUTED BY WORLD SCIENTIFIC PUBLISHING CO. eBooks | 10.1142/p291 |
| 9 | include | 0.685 | in_scope | 2021 | Frontiers in Theoretical Analysis of Solid Electrolyte Interphase Formation Mechanism | Advanced Materials | 10.1002/adma.202100574 |
| 10 | include | 0.682 | in_scope | 2019 | Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries | Nanoscale | 10.1039/c9nr05748j |

## Included Papers

| Rank | Score | Paper | Primary reason | Reading priority |
| ---: | ---: | --- | --- | --- |
| 1 | 0.779 | Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook | high_score_in_scope_grounded_evidence | must_read |
| 2 | 0.713 | Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries | high_score_in_scope_grounded_evidence | must_read |
| 3 | 0.711 | Capturing the swelling of solid-electrolyte interphase in lithium metal batteries | high_score_in_scope_grounded_evidence | must_read |
| 4 | 0.708 | A Perspective on the Molecular Modeling of Electrolyte Decomposition Reactions for Solid Electrolyte Interphase Growth in Lithium‐Ion Batteries | high_score_in_scope_grounded_evidence | must_read |
| 5 | 0.705 | Lignin‐derived hard carbon anode with a robust solid electrolyte interphase for boosted sodium storage performance | high_score_in_scope_grounded_evidence | must_read |
| 6 | 0.696 | Thermal Decomposition of the Solid Electrolyte Interphase (SEI) on Silicon Electrodes for Lithium Ion Batteries | high_score_in_scope_grounded_evidence | read_later |
| 7 | 0.695 | Transport of Ions, Molecules, and Electrons across the Solid Electrolyte Interphase: What Is Our Current Level of Understanding? | high_score_in_scope_grounded_evidence | read_later |
| 8 | 0.685 | Lithium-Ion Batteries | high_score_in_scope_grounded_evidence | read_later |
| 9 | 0.685 | Frontiers in Theoretical Analysis of Solid Electrolyte Interphase Formation Mechanism | high_score_in_scope_grounded_evidence | read_later |
| 10 | 0.682 | Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries | high_score_in_scope_grounded_evidence | read_later |

## Maybe / Needs Human Inspection

| Rank | Score | Paper | Primary reason | Suggested action |
| ---: | ---: | --- | --- | --- |
| 44 | 0.603 | Challenges and Recent Progress in the Development of Si Anodes for Lithium‐Ion Battery | partial_match_needs_inspection | uncertain |
| 55 | 0.550 | An Advanced Tool for the Selection of Electrolyte Components for Rechargeable Lithium Batteries | partial_match_needs_inspection | uncertain |
| 56 | 0.528 | Study of the Interface Between Li[sub 4]Ti[sub 5]O[sub 12] Electrodes and Standard Electrolyte Solutions in 0.0–0.5 V | partial_match_needs_inspection | uncertain |
| 57 | 0.515 | An Artificial Solid Electrolyte Interphase Enables the Use of a LiNi<sub>0.5</sub> Mn<sub>1.5</sub> O<sub>4</sub> 5 V Cathode with Conventional Electrolytes | partial_match_needs_inspection | uncertain |
| 58 | 0.493 | Lithium Dendrite Suppression and Enhanced Interfacial Compatibility Enabled by an Ex Situ SEI on Li Anode for LAGP-Based All-Solid-State Batteries | partial_match_needs_inspection | uncertain |
| 59 | 0.468 | Electrolyte engineering for highly inorganic solid electrolyte interphase in high-performance lithium metal batteries | missing_abstract | inspect_full_text |
| 60 | 0.449 | Direct in situ measurements of electrical properties of solid–electrolyte interphase on lithium metal anodes | missing_abstract | inspect_full_text |
| 61 | 0.444 | Real-time mass spectrometric characterization of the solid–electrolyte interphase of a lithium-ion battery | missing_abstract | inspect_full_text |
| 62 | 0.430 | Highly adaptable SEI/CEI interfacial layers enabling remarkable performance of high-nickel solid-state batteries | missing_abstract | inspect_full_text |
| 63 | 0.416 | Lithium ion battery degradation: what you need to know | off_topic_domain | uncertain |
| 64 | 0.403 | Review—“Knees” in Lithium-Ion Battery Aging Trajectories | off_topic_domain | uncertain |
| 65 | 0.398 | Advances and challenges in thermal runaway modeling of lithium-ion batteries | off_topic_domain | uncertain |
| 66 | 0.391 | Low‐temperature performance of Na‐ion batteries | off_topic_domain | uncertain |
| 67 | 0.383 | Review on the Experimental Characterization of Fracture in Active Material for Lithium-Ion Batteries | off_topic_domain | uncertain |
| 68 | 0.381 | Perspectives for next generation lithium-ion battery cathode materials | off_topic_domain | uncertain |

## Excluded Papers And Reasons

| Rank | Score | Paper | Primary reason | Exclusion reasons |
| ---: | ---: | --- | --- | --- |
| 90 | 0.346 | Modified solid-electrolyte interphase toward stable Li metal anode | missing_abstract | missing_abstract, missing_required_concept |
| 91 | 0.333 | Advanced Characterizations of Solid Electrolyte Interphases in Lithium-Ion Batteries | missing_abstract | missing_abstract, missing_required_concept |
| 92 | 0.294 | Electrolyte design for Li-ion batteries under extreme operating conditions | missing_abstract | missing_required_concept, missing_abstract |
| 93 | 0.249 | Modeling of lithium plating induced aging of lithium-ion batteries: Transition from linear to nonlinear aging | missing_abstract | missing_required_concept, missing_abstract |
| 94 | 0.249 | Characterization and performance evaluation of lithium-ion battery separators | missing_abstract | missing_required_concept, missing_abstract |
| 95 | 0.245 | Negating interfacial impedance in garnet-based solid-state Li metal batteries | missing_abstract | missing_required_concept, missing_abstract |
| 96 | 0.234 | Electrocatalytic transformation of HF impurity to H2 and LiF in lithium-ion batteries | missing_abstract | missing_required_concept, missing_abstract |
| 97 | 0.226 | Lithium-ion batteries – Current state of the art and anticipated developments | missing_abstract | missing_required_concept, missing_abstract |
| 98 | 0.210 | Studies on the Anode/Electrolyte Interfacein Lithium Ion Batteries | missing_abstract | missing_required_concept, missing_abstract |
| 99 | 0.207 | Reactions at the electrode/electrolyte interface of all-solid-state lithium batteries incorporating Li–M (M = Sn, Si) alloy electrodes and sulfide-based solid electrolytes | missing_abstract | missing_required_concept, missing_abstract |
| 100 | 0.207 | Cycling degradation of an automotive LiFePO4 lithium-ion battery | missing_abstract | missing_required_concept, missing_abstract |
| 101 | 0.204 | The formation and stability of the solid electrolyte interface on the graphite anode | missing_abstract | missing_required_concept, missing_abstract |
| 102 | 0.157 | Electrolyte Oxidation Pathways in Lithium-Ion Batteries | off_topic_domain | off_topic_domain, missing_required_concept, low_metadata_quality |

## Common Exclusion Reasons

- missing_required_concept: 95
- off_topic_domain: 24
- missing_abstract: 20
- low_metadata_quality: 1

## Method Comparison Matrix

| Paper | Method | Human role | Agent design | Evidence verification | Evaluation | Recommended use |
| --- | --- | --- | --- | --- | --- | --- |
| Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook | review or survey synthesis | not explicit | not explicit | strict_support; exact; confidence=1.00 | case study or experiment | future work |
| Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries | review or survey synthesis | not explicit | not explicit | strict_support; exact; confidence=1.00 | case study or experiment | background |
| Capturing the swelling of solid-electrolyte interphase in lithium metal batteries | system or framework | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | future work |
| A Perspective on the Molecular Modeling of Electrolyte Decomposition Reactions for Solid Electrolyte Interphase Growth in Lithium‐Ion Batteries | empirical evaluation | not explicit | not explicit | strict_support; exact; confidence=1.00 | case study or experiment | future work |
| Lignin‐derived hard carbon anode with a robust solid electrolyte interphase for boosted sodium storage performance | not explicit from title/abstract metadata | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | future work |
| Thermal Decomposition of the Solid Electrolyte Interphase (SEI) on Silicon Electrodes for Lithium Ion Batteries | model or algorithm | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | motivation |
| Transport of Ions, Molecules, and Electrons across the Solid Electrolyte Interphase: What Is Our Current Level of Understanding? | not explicit from title/abstract metadata | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | future work |
| Lithium-Ion Batteries | model or algorithm | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | motivation |
| Frontiers in Theoretical Analysis of Solid Electrolyte Interphase Formation Mechanism | review or survey synthesis | not explicit | not explicit | strict_support; exact; confidence=1.00 | case study or experiment | motivation |
| Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries | review or survey synthesis | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | motivation |
| Dynamics and morphology of solid electrolyte interphase (SEI) | empirical evaluation | not explicit | not explicit | strict_support; exact; confidence=1.00 | case study or experiment | motivation |
| Eliminating Graphite Exfoliation with an Artificial Solid Electrolyte Interphase for Stable Lithium‐Ion Batteries | not explicit from title/abstract metadata | not explicit | not explicit | strict_support; exact; confidence=1.00 | not explicit in abstract metadata | future work |

- Full matrix: `method_comparison_matrix.csv` and `method_comparison_matrix.md`.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Evidence verification is undercovered | Revisiting the t<sup>0.5</sup> Dependence of SEI Growth; Review on the Experimental Characterization of Fracture in Active Material for Lithium-Ion Batteries | 68 signal(s) suggest this aspect is undercovered across 102 screened paper(s). | Span-grounded verification for abstract-level evidence chains. | review_background; review_background: review; background; overview; introduction |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| "solid electrolyte interphase" SEI "span-grounded" "evidence verification" | Investigate undercovered gap: Evidence verification is undercovered | research_gap_matrix |
| "solid electrolyte interphase" SEI | Pilot search flagged drift for query: "lithium-ion battery" SEI | query_pilot_diagnostics |
| "solid electrolyte interphase" SEI electrolyte solid lithium | Expand around keywords from currently included papers. | included_paper_keywords |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

| Paper | Covered aspects | Missing aspects | Score |
| --- | --- | --- | ---: |
| Review on modeling of the anode solid electrolyte interphase (SEI) for lithium-ion batteries | review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI |  | 1.00 |
| 30 Years of Lithium‐Ion Batteries | review_background, theory_mechanism, materials_cases | methods_characterization, failure_limitation, solid electrolyte interphase, SEI | 0.43 |
| Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook | review_background, theory_mechanism, methods_characterization, materials_cases, failure_limitation, solid electrolyte interphase, SEI |  | 1.00 |
| Real-time mass spectrometric characterization of the solid–electrolyte interphase of a lithium-ion battery | methods_characterization, materials_cases, solid electrolyte interphase | review_background, theory_mechanism, failure_limitation, SEI | 0.43 |
| Materials for lithium-ion battery safety | review_background, materials_cases | theory_mechanism, methods_characterization, failure_limitation, solid electrolyte interphase, SEI | 0.29 |
| Lithium-Ion Batteries | theory_mechanism, methods_characterization, materials_cases, solid electrolyte interphase, SEI | review_background, failure_limitation | 0.71 |
| Challenges and Recent Progress in the Development of Si Anodes for Lithium‐Ion Battery | materials_cases, solid electrolyte interphase | review_background, theory_mechanism, methods_characterization, failure_limitation, SEI | 0.29 |
| Modeling of lithium plating induced aging of lithium-ion batteries: Transition from linear to nonlinear aging | theory_mechanism, materials_cases, failure_limitation | review_background, methods_characterization, solid electrolyte interphase, SEI | 0.43 |
| Synergetic Effects of Inorganic Components in Solid Electrolyte Interphase on High Cycle Efficiency of Lithium Ion Batteries | materials_cases, failure_limitation, solid electrolyte interphase, SEI | review_background, theory_mechanism, methods_characterization | 0.57 |
| Modeling and Applications of Electrochemical Impedance Spectroscopy (EIS) for Lithium-ion Batteries | review_background, theory_mechanism, methods_characterization, materials_cases, SEI | failure_limitation, solid electrolyte interphase | 0.71 |

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 20 papers
- recent_frontier: 12 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 1 papers
- background_or_survey: 37 papers
- peripheral: 11 papers
- excluded_or_low_confidence: 21 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |
| 1 | strict_support | exact | 1.00 | False | False | In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI). | In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI). | In lithium‐ion batteries, the electrochemical instability of the electrolyte and its ensuing reactive decomposition proceeds at the anode surface within the Helmholtz double layer resulting in a buildup of the reductive products, forming the solid electrolyte interphase (SEI). |
| 2 | strict_support | exact | 1.00 | False | False | Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes. | Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes. | Abstract A passivation layer called the solid electrolyte interphase (SEI) is formed on electrode surfaces from decomposition products of electrolytes. |
| 3 | strict_support | exact | 1.00 | False | False | We report substantial swelling of the solid-electrolyte interphase (SEI) on lithium metal anode in various electrolytes. | We report substantial swelling of the solid-electrolyte interphase (SEI) on lithium metal anode in various electrolytes. | We report substantial swelling of the solid-electrolyte interphase (SEI) on lithium metal anode in various electrolytes. |
| 4 | strict_support | exact | 1.00 | False | False | The solid electrolyte interphase (SEI) is a thin heterogeneous layer formed at the anode/electrolyte interface in lithium‐ion batteries as a consequence of the reduction of the electrolyte. | The solid electrolyte interphase (SEI) is a thin heterogeneous layer formed at the anode/electrolyte interface in lithium‐ion batteries as a consequence of the reduction of the electrolyte. | The solid electrolyte interphase (SEI) is a thin heterogeneous layer formed at the anode/electrolyte interface in lithium‐ion batteries as a consequence of the reduction of the electrolyte. |
| 5 | strict_support | exact | 1.00 | False | False | In addition, the solid electrolyte interphase (SEI) is subjected to continuous rupture during battery cycling, leading to fast capacity decay. | In addition, the solid electrolyte interphase (SEI) is subjected to continuous rupture during battery cycling, leading to fast capacity decay. | In addition, the solid electrolyte interphase (SEI) is subjected to continuous rupture during battery cycling, leading to fast capacity decay. |
| 6 | strict_support | exact | 1.00 | False | False | Thermal behavior of the solid electrolyte interphase (SEI) on a silicon electrode for lithium ion batteries has been investigated by TGA. | Thermal behavior of the solid electrolyte interphase (SEI) on a silicon electrode for lithium ion batteries has been investigated by TGA. | Thermal behavior of the solid electrolyte interphase (SEI) on a silicon electrode for lithium ion batteries has been investigated by TGA. |
| 7 | strict_support | exact | 1.00 | False | False | Abstract The solid electrolyte interphase (SEI) on the graphite particles of lithium‐ion battery anodes passivates the anode against electrolyte reduction due to electron transfer reactions, and a stable and well‐passivating SEI is an important prerequisite for a long cycle life of batteries. | Abstract The solid electrolyte interphase (SEI) on the graphite particles of lithium‐ion battery anodes passivates the anode against electrolyte reduction due to electron transfer reactions, and a stable and well‐passivating SEI is an important prerequisite for a long cycle life of batteries. | Abstract The solid electrolyte interphase (SEI) on the graphite particles of lithium‐ion battery anodes passivates the anode against electrolyte reduction due to electron transfer reactions, and a stable and well‐passivating SEI is an important prerequisite for a long cycle life of batteries. |
| 8 | strict_support | exact | 1.00 | False | False | SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interp | SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interp | SEI on Lithium, Graphite, Disordered Carbons and Tin-Based Alloys (E Peled & D Golodnitsky) Identification of Surface Films on Electrodes in Non-Aqueous Electrolyte Solutions: Spectroscopic, Electronic and Morphological Studies (D Aurbach & Y S Cohen) Spectroscopy Studies of Solid-Electrolyte Interp |
| 9 | strict_support | exact | 1.00 | False | False | Solid electrolyte interphase (SEI) is an ion conductive yet electron-insulating layer on battery electrodes, which is formed by the reductive decomposition of electrolytes during the initial charge. | Solid electrolyte interphase (SEI) is an ion conductive yet electron-insulating layer on battery electrodes, which is formed by the reductive decomposition of electrolytes during the initial charge. | Solid electrolyte interphase (SEI) is an ion conductive yet electron-insulating layer on battery electrodes, which is formed by the reductive decomposition of electrolytes during the initial charge. |
| 10 | strict_support | exact | 1.00 | False | False | The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition. | The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition. | The solid electrolyte interface (SEI) is a passivation layer formed on the surface of lithium-ion battery (LIB) anode materials produced by electrolyte decomposition. |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.196
- Unsupported claim rate: 0.196
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: overview
- Planner: 17 planned query strings.
- Retriever: 340 raw records, 102 merged records.
- Domain guardrail: 68 in_scope, 33 borderline, 1 out_of_scope.
- Screening decision agent: 53 include, 36 maybe, 13 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
