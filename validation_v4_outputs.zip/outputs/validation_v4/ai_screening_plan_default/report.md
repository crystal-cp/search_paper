# Literature Screening Decision Report

## Research Question

我想找 LLM 用于系统综述文献筛选的人机协作论文，重点关注人工反馈、证据验证、召回率和筛选准确率。

## Question Preprocessing

Planning question: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.

Translated question: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.

## How the system corrected the user’s question

- User original wording: 我想找 LLM 用于系统综述文献筛选的人机协作论文，重点关注人工反馈、证据验证、召回率和筛选准确率。
- Expert rewritten question: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.
- Downweighted user terms: review
- Expert concepts added: literature screening, LLM, human-in-the-loop, multi-agent system

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording: none recorded
- Selected interpretation: Not explicitly selected.
- Why this interpretation: Not generated in this run.
- User words not mechanically used as hard query terms: review

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| LLM | mechanism | user_text | must | yes | User explicitly asks about LLM-based systems. |
| literature screening | object | user_text | must | yes | User asks about literature screening. |
| human-in-the-loop | mechanism | user_text | must | yes | User asks about human collaboration. |
| multi-agent system | mechanism | domain_pack | optional | yes | LLM screening systems may use multi-agent workflow; keep optional unless explicit. |
| evidence verification | application | domain_pack | optional | yes | Literature screening often needs evidence verification. |

Downweighted terms: review

Optional or uncertain concepts: multi-agent system, evidence verification
- Assumptions needing confirmation or verification:
  - This is an AI literature-screening question, not a materials-magnetism question.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.

## What the System Thinks the User Is Looking For

- Refined question: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.
- Search intent: evidence_verification
- User goal: Find AI and human-in-the-loop papers about LLM-assisted literature screening.
- Inclusion criteria: review literature screening evidence verification human feedback llm, evidence, evaluation, literature screening, LLM, human-in-the-loop, multi-agent system
- Exclusion criteria: 
- Required aspects: review, literature, screening, claim, evidence, evaluation, core concept coverage, application or motivation bridge
- Preferred paper types: evaluation paper, benchmark paper, empirical study, theoretical paper
- Time window: no strict time window
- Success definition: Grounded papers with auditable abstract evidence.

## Search Contract

- Domain: ai_literature_screening
- Positive domains: ai literature screening
- Negative domains: clinical screening, patient screening, drug screening, biomarker screening, high-throughput materials screening, materials screening, biological agent, chemical agent, infectious agent
- Must include concepts: LLM, literature screening, human-in-the-loop
- Must exclude concepts: clinical screening, patient screening, drug screening, biomarker screening, high-throughput materials screening, materials screening, biological agent, chemical agent, infectious agent
- Required aspects: screening_workflow: literature screening; abstract screening; study selection; systematic review, human_feedback: human feedback; human-in-the-loop; human collaboration, evidence_validation: evidence verification; evidence validation; claim extraction; grounded evidence, performance_metrics: recall; accuracy; screening accuracy; evaluation metric, review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, application_performance: application; performance; activity; accuracy; recall; metric, LLM, literature screening, human-in-the-loop
- Field whitelist: Computer Science, Information Retrieval, Artificial Intelligence
- Field blacklist: Medicine, Biology

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: LLM, literature screening, human-in-the-loop
- Must terms: LLM, literature screening, human-in-the-loop
- Optional terms: 
- Exclude terms: clinical screening, patient screening, drug screening, biomarker screening, high-throughput materials screening, materials screening, biological agent, chemical agent, infectious agent
- Required aspects: screening_workflow: literature screening; abstract screening; study selection; systematic review, human_feedback: human feedback; human-in-the-loop; human collaboration, evidence_validation: evidence verification; evidence validation; claim extraction; grounded evidence, performance_metrics: recall; accuracy; screening accuracy; evaluation metric, review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, application_performance: application; performance; activity; accuracy; recall; metric, LLM, literature screening, human-in-the-loop
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'ai_literature_screening', 'intent_domain': 'ai_literature_screening', 'must_term_groups': [['LLM', 'literature screening', 'human-in-the-loop'], ['literature screening'], ['LLM'], ['human-in-the-loop'], ['multi-agent system'], ['evidence verification']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['LLM', 'literature screening', 'human-in-the-loop'], 'source': 'expert_intent', 'required': True}, {'group_name': 'core_object_group_1', 'operator': 'OR', 'terms': ['literature screening'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_2', 'operator': 'OR', 'terms': ['LLM'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_3', 'operator': 'OR', 'terms': ['human-in-the-loop'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'core_object_group_4', 'operator': 'OR', 'terms': ['multi-agent system'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'domain_context_group', 'operator': 'OR', 'terms': ['evidence verification'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['literature screening', 'screening', 'workflows', 'and collaboration workflows', 'large language model', 'scientific', 'including', 'selection', 'verification', 'collaboration'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'mechanism_group', 'operator': 'OR', 'terms': ['LLM', 'human-in-the-loop', 'multi-agent system'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'material_or_case_group', 'operator': 'OR', 'terms': ['multi-agent system', 'systems'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'application_or_metric_group', 'operator': 'OR', 'terms': ['evidence verification'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': [], 'intent_methods': [], 'intent_repair_used': True, 'structured_concepts': [{'term': 'review', 'category': 'generic_user_term', 'source': 'user_text', 'confidence': 0.95, 'activation_reason': 'Generic novice wording helps interpret motivation but should not drive provider queries.', 'query_role': 'downweighted', 'should_use_in_provider_query': False}, {'term': 'LLM', 'category': 'mechanism', 'source': 'user_text', 'confidence': 0.92, 'activation_reason': 'User explicitly asks about LLM-based systems.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'literature screening', 'category': 'object', 'source': 'user_text', 'confidence': 0.94, 'activation_reason': 'User asks about literature screening.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'human-in-the-loop', 'category': 'mechanism', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'User asks about human collaboration.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'multi-agent system', 'category': 'mechanism', 'source': 'domain_pack', 'confidence': 0.7, 'activation_reason': 'LLM screening systems may use multi-agent workflow; keep optional unless explicit.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'evidence verification', 'category': 'application', 'source': 'domain_pack', 'confidence': 0.68, 'activation_reason': 'Literature screening often needs evidence verification.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想找 LLM 用于系统综述文献筛选的人机协作论文，重点关注人工反馈、证据验证、召回率和筛选准确率。
- Refined question: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.
- Search intent: evidence_verification
- User goal: Find AI and human-in-the-loop papers about LLM-assisted literature screening.
- Domain: ai_literature_screening
- Must include concepts: LLM, literature screening, human-in-the-loop
- Must exclude concepts: clinical screening, patient screening, drug screening, biomarker screening, high-throughput materials screening, materials screening, biological agent, chemical agent
- Core terms: LLM, literature screening, human-in-the-loop
- Expert rewrite: Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.
- Downweighted user terms: review

## 2. Concept decomposition

- Domain: ai_literature_screening
- Central question: 我想找 LLM 用于系统综述文献筛选的人机协作论文，重点关注人工反馈、证据验证、召回率和筛选准确率。 Find papers on human-in-the-loop LLM systems for scientific literature screening, including study selection, evidence verification, and collaboration workflows.
- core_topic: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems
- theory_mechanism: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems
- characterization_methods: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems
- materials_or_cases: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems
- application_or_performance: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems
- human_feedback: concepts=literature screening, LLM, human-in-the-loop, multi-agent system; methods=literature screening, screening, workflows, and collaboration workflows, large language model; materials=evidence verification, multi-agent system, systems

## 3. Search lenses and query families

- Query families generated: 8
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- theory_mechanism (lens=theory_mechanism): find theory, mechanism, model, or causal-relation papers; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- materials_or_cases (lens=materials_or_cases): find representative materials, systems, benchmarks, or case studies; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- application_or_performance (lens=application_or_performance): find applications, device relevance, activity, metrics, or performance papers; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- human_feedback (lens=human_feedback): find human feedback and human-in-the-loop workflow papers; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- evidence_validation (lens=evidence_validation): find evidence validation and verification methods; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"
- performance_metrics (lens=performance_metrics): find recall, accuracy, and evaluation-metric evidence; sample queries=openalex: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback" \| semantic_scholar: LLM "systematic review screening"; LLM "large language model" "literature screening" "human feedback"

## 4. Screening and inclusion criteria

- Inclusion criteria: review literature screening evidence verification human feedback llm, evidence, evaluation, literature screening, LLM, human-in-the-loop, multi-agent system
- Exclusion criteria: 
- Required aspects: review, literature, screening, claim, evidence, evaluation, core concept coverage, application or motivation bridge
- Contract inclusion criteria: review literature screening evidence verification human feedback llm, evidence, evaluation, literature screening, LLM, human-in-the-loop, multi-agent system
- Contract exclusion criteria: 

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 0 paper(s)
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 0 paper(s)
- review_background: 0 paper(s)

## 6. Research lineage

Not generated in this run.
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Human feedback is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Evidence verification is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Evaluation protocol is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Human feedback is undercovered: 
  - Evidence verification is undercovered: 
  - Evaluation protocol is undercovered: 
- Lens methods to audit: literature screening, screening, workflows, and collaboration workflows, large language model, scientific, including, selection, verification, collaboration
- Lens materials to audit: evidence verification, multi-agent system, systems
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- LLM "literature screening" human-in-the-loop "human feedback" "query refinement"
- LLM "literature screening" human-in-the-loop "span-grounded" "evidence verification"
- LLM "literature screening" human-in-the-loop "benchmark" "evaluation protocol"

## 10. Verified vs uncertain findings

- Verified:
  - No strict or span-validated findings were available.
- Uncertain:
  - No uncertain findings were identified.
- Evidence functions observed: 

## Planned Queries

- LLM "systematic review screening"
- LLM "large language model" "literature screening" "human feedback"
- LLM "systematic review" "evidence validation"
- LLM "literature screening" "recall accuracy"
- LLM human-in-the-loop "systematic review screening"

## Domain Guardrails

- In scope: 0
- Borderline: 0
- Out of scope: 0

- No papers were demoted by domain guardrails.

## Query Pilot Diagnostics

- Pilot search was not run for this report.

## Query Repairs Applied

- Auto repair applied: False

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
|  |  |  |  | static_query_quality_repair |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 0
- Merged paper count: 0
- Duplicate count: 0
- Counts by provider: {'openalex': 0, 'semantic_scholar': 0}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 0
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 0
- Records identified by Semantic Scholar: 0
- Duplicate records removed: 0
- Records with missing abstracts: 0
- Records screened: 0
- Records included: 0
- Records maybe: 0
- Records excluded: 0
- Out-of-domain records: 0
- Included in top ranked results: 0
- Excluded or low confidence: 0
- Common exclusion reasons: {}

## Provider Status

| Provider | Status | Queries attempted | Papers returned | Notes |
| --- | --- | ---: | ---: | --- |
| openalex | not_attempted | 0 | 0 | stopped after 0 queries |
| semantic_scholar | not_attempted | 0 | 0 | stopped after 0 queries |

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

`strict_support` means the evidence sentence was grounded in the abstract. It is not a claim that the paper is highly relevant; use intent match and reading priority separately.

- Strict supported count: 0
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 0.000
- Strict support rate: 0.000
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.000

## Scoring Formula

`base_score = weighted relevance/evidence/recency/quality/diversity; pre_domain_score = 0.52 * intent_centrality_score + 0.48 * base_score when intent centrality is available; then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Evidence grounding | Intent match | Reading priority | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | ---: | --- | --- | --- |

## Included Papers

- No papers were automatically marked include.

## Maybe / Needs Human Inspection

- No papers were marked maybe.

## Excluded Papers And Reasons

- No papers were automatically excluded.

## Common Exclusion Reasons

- No exclusion reasons were recorded.

## Method Comparison Matrix

- No method comparison rows were generated.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Human feedback is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Feedback-aware query refinement and reranking loop. | human-in-the-loop; human_feedback: human feedback; human-in-the-loop; human collaboration |
| Evidence verification is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Span-grounded verification for abstract-level evidence chains. | evidence_validation: evidence verification; evidence validation; claim extraction; grounded evidence; review_background: review; background; overview; introduction |
| Evaluation protocol is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Benchmarking and evaluation protocol for literature screening agents. | application_performance: application; performance; activity; accuracy; recall; metric; materials_cases: material; system; case study; benchmark; performance_metrics: recall; accuracy; screening accuracy; evaluation metric |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| LLM "literature screening" human-in-the-loop "human feedback" "query refinement" | Investigate undercovered gap: Human feedback is undercovered | research_gap_matrix |
| LLM "literature screening" human-in-the-loop "span-grounded" "evidence verification" | Investigate undercovered gap: Evidence verification is undercovered | research_gap_matrix |
| LLM "literature screening" human-in-the-loop "benchmark" "evaluation protocol" | Investigate undercovered gap: Evaluation protocol is undercovered | research_gap_matrix |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

- No required aspects were classified.

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 0 papers
- recent_frontier: 0 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 0 papers
- background_or_survey: 0 papers
- peripheral: 0 papers
- excluded_or_low_confidence: 0 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.000
- Unsupported claim rate: 0.000
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: evidence_verification
- Planner: 5 planned query strings.
- Retriever: 0 raw records, 0 merged records.
- Domain guardrail: 0 in_scope, 0 borderline, 0 out_of_scope.
- Screening decision agent: 0 include, 0 maybe, 0 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
