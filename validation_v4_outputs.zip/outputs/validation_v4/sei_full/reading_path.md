# Recommended Reading Path

## Overview / Background

- #15: Role of Lithium Salt on Solid Electrolyte Interface (SEI) Formation and Structure in Lithium Ion Batteries
- #20: Ultra-thin solid electrolyte interphase evolution and wrinkling processes in molybdenum disulfide-based lithium-ion batteries

## Core System / Method Papers

- #1: Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook
- #2: Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries
- #3: Lithium-Ion Batteries

## Recent Frontier Papers

- #25: A jigsaw-structured artificial solid electrolyte interphase for high-voltage lithium metal batteries
- #29: An active learning approach to model solid-electrolyte interphase formation in Li-ion batteries

## Evaluation Papers

- #86: Machine-learning-accelerated mechanistic exploration of interface modification in lithium metal anode
- #1: Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook

## Optional Peripheral Papers

- #1: Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook
- #2: Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries
