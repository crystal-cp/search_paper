# Recommended Reading Path

## Overview / Background

- #5: A review on fundamentals for designing oxygen evolution electrocatalysts
- #6: Advanced Transition Metal‐Based OER Electrocatalysts: Current Status, Opportunities, and Challenges

## Core System / Method Papers

- #1: Low-spin state of Fe in Fe-doped NiOOH electrocatalysts
- #2: Advances in Spin Catalysts for Oxygen Evolution and Reduction Reactions
- #3: Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts

## Recent Frontier Papers

- #4: Spin Effects in Chemisorption and Catalysis
- #7: Spin-Modulated Oxygen Electrocatalysis

## Evaluation Papers

- #46: Strongly correlated and topological states in [111] grown transition metal oxide thin films and heterostructures
- #1: Low-spin state of Fe in Fe-doped NiOOH electrocatalysts

## Optional Peripheral Papers

- #19: Tuning the Spin Density of Cobalt Single-Atom Catalysts for Efficient Oxygen Evolution
- #21: A Fundamental Relationship between Reaction Mechanism and Stability in Metal Oxide Catalysts for Oxygen Evolution
- #28: Theoretical Investigation of the Activity of Cobalt Oxides for the Electrochemical Oxidation of Water
