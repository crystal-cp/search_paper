# Paper Evidence Cards

## 1. Low-spin state of Fe in Fe-doped NiOOH electrocatalysts

- Year / venue / citations: 2023 | Nature Communications | 146
- DOI or URL: 10.1038/s41467-023-38978-5
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.853, relevance=0.432, evidence=0.745
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, controversy_debate
- Claim: The low-spin state renders the surface Fe sites highly active for the OER.
- Evidence sentence: The low-spin state renders the surface Fe sites highly active for the OER.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Advances in Spin Catalysts for Oxygen Evolution and Reduction Reactions

- Year / venue / citations: 2022 | Small | 59
- DOI or URL: 10.1002/smll.202205638
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.836, relevance=0.306, evidence=0.673
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: methods_characterization, controversy_debate
- Claim: As the catalytic reaction occurs at the surface or edge, the unsaturated ions may lead to the fluctuation of spin.
- Evidence sentence: As the catalytic reaction occurs at the surface or edge, the unsaturated ions may lead to the fluctuation of spin.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 3. Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts

- Year / venue / citations: 2024 | Advanced Materials | 89
- DOI or URL: 10.1002/adma.202400572
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.832, relevance=0.310, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate
- Claim: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Evidence sentence: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 4. Spin Effects in Chemisorption and Catalysis

- Year / venue / citations: 2023 | ACS Catalysis | 150
- DOI or URL: 10.1021/acscatal.2c06319
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.478, relevance=0.352, evidence=0.745
- Domain decision: borderline
- Covered aspects: theory_mechanism, materials_cases, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate, OER
- Claim: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Evidence sentence: Finally, we discuss how spin effects may be used to control surface reactivity and provide guidance on how to alter the surface spin state, e.g., adding a metal promotor.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 5. A review on fundamentals for designing oxygen evolution electrocatalysts

- Year / venue / citations: 2020 | Chemical Society Reviews | 2773
- DOI or URL: 10.1039/c9cs00607a
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.476, relevance=0.324, evidence=0.673
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: The catalyst design has to be built based on the fundamental understanding of the OER mechanism and the origin of the reaction overpotential.
- Evidence sentence: The catalyst design has to be built based on the fundamental understanding of the OER mechanism and the origin of the reaction overpotential.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 6. Advanced Transition Metal‐Based OER Electrocatalysts: Current Status, Opportunities, and Challenges

- Year / venue / citations: 2021 | Small | 984
- DOI or URL: 10.1002/smll.202100129
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.475, relevance=0.386, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, methods_characterization, materials_cases, OER
- Missing aspects: controversy_debate, surface spin state
- Claim: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Evidence sentence: Then, recent developments and breakthroughs in experimental achievements on transition metal-based OER electrocatalysts are reviewed to reveal the novel design principles.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 7. Spin-Modulated Oxygen Electrocatalysis

- Year / venue / citations: 2023 | Precision Chemistry | 108
- DOI or URL: 10.1021/prechem.3c00059
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.474, relevance=0.329, evidence=0.745
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, OER, surface spin state
- Missing aspects: methods_characterization, materials_cases, controversy_debate
- Claim: It is demonstrated that the spin states (low, intermediate, and high spin) of magnetic transition metal catalysts (TMCs) can directly affect the reaction barriers of OER/ORR by tailoring the bonding of oxygen intermediates with TMCs.
- Evidence sentence: It is demonstrated that the spin states (low, intermediate, and high spin) of magnetic transition metal catalysts (TMCs) can directly affect the reaction barriers of OER/ORR by tailoring the bonding of oxygen intermediates with TMCs.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 8. An enhanced oxygen evolution reaction on 2D CoOOH <i>via</i> strain engineering: an insightful view from spin state transition

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 90
- DOI or URL: 10.1039/d1ta03412j
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.472, relevance=0.312, evidence=0.673
- Domain decision: borderline
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: Spin state of Co 3+ ion transfers from low spin (LS: t62ge0g) to high spin (HS: t42ge2g) under strain engineering.
- Evidence sentence: Spin state of Co 3+ ion transfers from low spin (LS: t62ge0g) to high spin (HS: t42ge2g) under strain engineering.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 9. Tuning α‐MnOOH Formation via Atomic‐Level Fe Introduction for Superior OER Performance

- Year / venue / citations: 2025 | Advanced Functional Materials | 63
- DOI or URL: 10.1002/adfm.202503360
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.472, relevance=0.312, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: Theoretical calculations also demonstrate that the effective active sites regulated in the representative catalyst of α‐MnOOH can reduce the energy barrier for a crucial step during the OER process (the *O to *OOH transition), thus significantly enhancing catalytic performance.
- Evidence sentence: Theoretical calculations also demonstrate that the effective active sites regulated in the representative catalyst of α‐MnOOH can reduce the energy barrier for a crucial step during the OER process (the *O to *OOH transition), thus significantly enhancing catalytic performance.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 10. The electronic structure of transition metal oxides for oxygen evolution reaction

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 261
- DOI or URL: 10.1039/d1ta03732c
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.471, relevance=0.339, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Evidence sentence: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 11. Spin-polarized oxygen evolution reaction under magnetic field

- Year / venue / citations: 2021 | Nature Communications | 683
- DOI or URL: 10.1038/s41467-021-22865-y
- Decision: maybe
- Reading priority: optional
- Recommended role: background
- Why relevant: score=0.471, relevance=0.360, evidence=0.709
- Domain decision: borderline
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: We found that the spin polarization occurs at the first electron transfer step in OER, where coherent spin exchange happens between the ferromagnetic catalyst and the adsorbed oxygen species with fast kinetics, under the principle of spin angular momentum conservation.
- Evidence sentence: We found that the spin polarization occurs at the first electron transfer step in OER, where coherent spin exchange happens between the ferromagnetic catalyst and the adsorbed oxygen species with fast kinetics, under the principle of spin angular momentum conservation.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 12. Multicomponent transition metal oxides and (oxy)hydroxides for oxygen evolution

- Year / venue / citations: 2022 | Nano Research | 146
- DOI or URL: 10.1007/s12274-022-4874-7
- Decision: maybe
- Reading priority: optional
- Recommended role: future work
- Why relevant: score=0.471, relevance=0.358, evidence=0.709
- Domain decision: borderline
- Covered aspects: review_background, theory_mechanism, materials_cases, OER
- Missing aspects: methods_characterization, controversy_debate, surface spin state
- Claim: Multicomponent transition metal oxides and (oxy)hydroxides are the most promising OER catalysts due to their low cost, adjustable structure, high electrocatalytic activity, and outstanding durability.
- Evidence sentence: Multicomponent transition metal oxides and (oxy)hydroxides are the most promising OER catalysts due to their low cost, adjustable structure, high electrocatalytic activity, and outstanding durability.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain
