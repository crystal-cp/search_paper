# Research Gap Matrix

| gap_key | gap_label | gap | evidence_or_reason | supporting_papers | why_gap_remains | possible_project_idea | suggested_next_searches | confidence | related_aspects |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  | Theory and mechanism background is undercovered |  | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Synthesize theoretical background with experimentally grounded mechanism evidence. |  |  | theory_mechanism: theory; mechanism; model; explanation |
|  |  | Characterization methods are undercovered |  | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Build a method-comparison table across direct, indirect, in situ, and ex situ probes. |  |  | methods_characterization: method; characterization; measurement; probe; experiment |
