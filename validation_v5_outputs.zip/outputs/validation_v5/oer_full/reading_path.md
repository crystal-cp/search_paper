# Recommended Reading Path

## Overview / Background

- #1: An enhanced oxygen evolution reaction on 2D CoOOH <i>via</i> strain engineering: an insightful view from spin state transition
- #7: The electronic structure of transition metal oxides for oxygen evolution reaction

## Core System / Method Papers

- #2: Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts
- #3: Tailoring the Co 3d-O 2p Covalency in LaCoO<sub>3</sub> by Fe Substitution To Promote Oxygen Evolution Reaction
- #5: Tuning the Spin Density of Cobalt Single-Atom Catalysts for Efficient Oxygen Evolution

## Recent Frontier Papers

- #4: High-spin Co3+ in cobalt oxyhydroxide for efficient water oxidation
- #37: Tuning α‐MnOOH Formation via Atomic‐Level Fe Introduction for Superior OER Performance

## Evaluation Papers

- #65: Strongly correlated and topological states in [111] grown transition metal oxide thin films and heterostructures
- #2: Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts

## Optional Peripheral Papers

- #36: A Fundamental Relationship between Reaction Mechanism and Stability in Metal Oxide Catalysts for Oxygen Evolution
- #39: Theoretical Investigation of the Activity of Cobalt Oxides for the Electrochemical Oxidation of Water
- #49: The latest development of CoOOH two-dimensional materials used as OER catalysts
