# Paper Evidence Cards

## 1. An enhanced oxygen evolution reaction on 2D CoOOH <i>via</i> strain engineering: an insightful view from spin state transition

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 90
- DOI or URL: 10.1039/d1ta03412j
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.837, relevance=0.312, evidence=0.673
- Domain decision: in_scope
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: Spin state of Co 3+ ion transfers from low spin (LS: t62ge0g) to high spin (HS: t42ge2g) under strain engineering.
- Evidence sentence: Spin state of Co 3+ ion transfers from low spin (LS: t62ge0g) to high spin (HS: t42ge2g) under strain engineering.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 2. Enhanced Oxygen Evolution and Zinc‐Air Battery Performance via Electronic Spin Modulation in Heterostructured Catalysts

- Year / venue / citations: 2024 | Advanced Materials | 89
- DOI or URL: 10.1002/adma.202400572
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.832, relevance=0.310, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate
- Claim: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Evidence sentence: Herein, spin modulation is achieved by engineering Ni/MnFe 2 O 4 heterojunctions, whose surface is reconstructed into NiOOH/MnFeOOH during the OER.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 3. Tailoring the Co 3d-O 2p Covalency in LaCoO<sub>3</sub> by Fe Substitution To Promote Oxygen Evolution Reaction

- Year / venue / citations: 2017 | Chemistry of Materials | 374
- DOI or URL: 10.1021/acs.chemmater.7b04534
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.832, relevance=0.378, evidence=0.745
- Domain decision: in_scope
- Covered aspects: theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: review_background, methods_characterization, controversy_debate
- Claim: X-ray absorption near-edge structure (XANES) supports DFT calculations on an insulator to half-metal transition with 10 at% Fe substitution, induced by spin state transition.
- Evidence sentence: X-ray absorption near-edge structure (XANES) supports DFT calculations on an insulator to half-metal transition with 10 at% Fe substitution, induced by spin state transition.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 4. High-spin Co3+ in cobalt oxyhydroxide for efficient water oxidation

- Year / venue / citations: 2024 | Nature Communications | 227
- DOI or URL: 10.1038/s41467-024-45702-4
- Decision: maybe
- Reading priority: read_later
- Recommended role: future work
- Why relevant: score=0.829, relevance=0.249, evidence=0.709
- Domain decision: in_scope
- Covered aspects: materials_cases, OER
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: As a result, the high-spin state CoOOH performs superior OER activity with an overpotential of 226 mV at 10 mA cm −2 , which is 148 mV lower than that of the low-spin state CoOOH.
- Evidence sentence: As a result, the high-spin state CoOOH performs superior OER activity with an overpotential of 226 mV at 10 mA cm −2 , which is 148 mV lower than that of the low-spin state CoOOH.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: uncertain

## 5. Tuning the Spin Density of Cobalt Single-Atom Catalysts for Efficient Oxygen Evolution

- Year / venue / citations: 2021 | ACS Nano | 202
- DOI or URL: 10.1021/acsnano.1c00251
- Decision: include
- Reading priority: must_read
- Recommended role: motivation
- Why relevant: score=0.824, relevance=0.291, evidence=0.673
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, controversy_debate
- Claim: Here, we synthesized ferromagnetic single Co atom catalysts on TaS2 monolayers (Co1/TaS2) as a model system to explore the spin–activity correlation for the oxygen evolution reaction (OER).
- Evidence sentence: Here, we synthesized ferromagnetic single Co atom catalysts on TaS2 monolayers (Co1/TaS2) as a model system to explore the spin–activity correlation for the oxygen evolution reaction (OER).
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 6. Regulating the Spin State of Fe<sup>III</sup> by Atomically Anchoring on Ultrathin Titanium Dioxide for Efficient Oxygen Evolution Electrocatalysis

- Year / venue / citations: 2019 | Angewandte Chemie International Edition | 350
- DOI or URL: 10.1002/anie.201913080
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.822, relevance=0.328, evidence=0.709
- Domain decision: in_scope
- Covered aspects: methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, controversy_debate
- Claim: Abstract Ferric oxides and (oxy)hydroxides, although plentiful and low‐cost, are rarely considered for oxygen evolution reaction (OER) owing to the too high spin state (e g filling ca.
- Evidence sentence: Abstract Ferric oxides and (oxy)hydroxides, although plentiful and low‐cost, are rarely considered for oxygen evolution reaction (OER) owing to the too high spin state (e g filling ca.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 7. The electronic structure of transition metal oxides for oxygen evolution reaction

- Year / venue / citations: 2021 | Journal of Materials Chemistry A | 261
- DOI or URL: 10.1039/d1ta03732c
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.812, relevance=0.339, evidence=0.709
- Domain decision: in_scope
- Covered aspects: review_background, materials_cases, OER
- Missing aspects: theory_mechanism, methods_characterization, controversy_debate, surface spin state
- Claim: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Evidence sentence: In this review article, we summarise the key electronic features of transition metal oxides that govern their OER catalytic properties, and how such electronic descriptors are applied for OER electrocatalysts design.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 8. Advances in Spin Catalysts for Oxygen Evolution and Reduction Reactions

- Year / venue / citations: 2022 | Small | 59
- DOI or URL: 10.1002/smll.202205638
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.810, relevance=0.306, evidence=0.673
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, OER, surface spin state
- Missing aspects: methods_characterization, controversy_debate
- Claim: As the catalytic reaction occurs at the surface or edge, the unsaturated ions may lead to the fluctuation of spin.
- Evidence sentence: As the catalytic reaction occurs at the surface or edge, the unsaturated ions may lead to the fluctuation of spin.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 9. Multicomponent transition metal oxides and (oxy)hydroxides for oxygen evolution

- Year / venue / citations: 2022 | Nano Research | 146
- DOI or URL: 10.1007/s12274-022-4874-7
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.807, relevance=0.358, evidence=0.709
- Domain decision: in_scope
- Covered aspects: review_background, theory_mechanism, materials_cases, OER
- Missing aspects: methods_characterization, controversy_debate, surface spin state
- Claim: Multicomponent transition metal oxides and (oxy)hydroxides are the most promising OER catalysts due to their low cost, adjustable structure, high electrocatalytic activity, and outstanding durability.
- Evidence sentence: Multicomponent transition metal oxides and (oxy)hydroxides are the most promising OER catalysts due to their low cost, adjustable structure, high electrocatalytic activity, and outstanding durability.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 10. Low-spin state of Fe in Fe-doped NiOOH electrocatalysts

- Year / venue / citations: 2023 | Nature Communications | 146
- DOI or URL: 10.1038/s41467-023-38978-5
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.806, relevance=0.432, evidence=0.745
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, controversy_debate
- Claim: The low-spin state renders the surface Fe sites highly active for the OER.
- Evidence sentence: The low-spin state renders the surface Fe sites highly active for the OER.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 11. SmCo<sub>5</sub> with a Reconstructed Oxyhydroxide Surface for Spin‐Selective Water Oxidation at Elevated Temperature

- Year / venue / citations: 2021 | Angewandte Chemie International Edition | 105
- DOI or URL: 10.1002/anie.202109065
- Decision: include
- Reading priority: must_read
- Recommended role: background
- Why relevant: score=0.803, relevance=0.308, evidence=0.709
- Domain decision: in_scope
- Covered aspects: materials_cases, OER, surface spin state
- Missing aspects: review_background, theory_mechanism, methods_characterization, controversy_debate
- Claim: Surface‐reconstructed ferromagnetic (FM) catalysts with a spin‐pinning effect at the FM/oxyhydroxide interface could enhance the spin‐dependent OER kinetics.
- Evidence sentence: Surface‐reconstructed ferromagnetic (FM) catalysts with a spin‐pinning effect at the FM/oxyhydroxide interface could enhance the spin‐dependent OER kinetics.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include

## 12. Low‐Spin Fe<sup>3+</sup> Evoked by Multiple Defects with Optimal Intermediate Adsorption Attaining Unparalleled Performance in Water Oxidation

- Year / venue / citations: 2024 | Advanced Materials | 133
- DOI or URL: 10.1002/adma.202412598
- Decision: include
- Reading priority: must_read
- Recommended role: future work
- Why relevant: score=0.800, relevance=0.311, evidence=0.709
- Domain decision: in_scope
- Covered aspects: theory_mechanism, methods_characterization, materials_cases, OER, surface spin state
- Missing aspects: review_background, controversy_debate
- Claim: Abstract Electrocatalytic water splitting is long constrained by the sluggish kinetics of anodic oxygen evolution reaction (OER), and rational spin‐state manipulation holds great promise to break through this bottleneck.
- Evidence sentence: Abstract Electrocatalytic water splitting is long constrained by the sluggish kinetics of anodic oxygen evolution reaction (OER), and rational spin‐state manipulation holds great promise to break through this bottleneck.
- Verification result: strict_support (exact, confidence=1.00)
- Limitations: The evidence sentence is grounded by an exact abstract span.
- Suggested action: include
