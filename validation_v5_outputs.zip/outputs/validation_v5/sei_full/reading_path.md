# Recommended Reading Path

## Overview / Background

- #9: Role of Lithium Salt on Solid Electrolyte Interface (SEI) Formation and Structure in Lithium Ion Batteries
- #15: An Artificial Solid Electrolyte Interphase with High Li‐Ion Conductivity, Mechanical Strength, and Flexibility for Stable Lithium Metal Anodes

## Core System / Method Papers

- #1: Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook
- #2: Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries
- #3: The state of understanding of the lithium-ion-battery graphite solid electrolyte interphase (SEI) and its relationship to formation cycling

## Recent Frontier Papers

- #10: A jigsaw-structured artificial solid electrolyte interphase for high-voltage lithium metal batteries
- #24: <i>In situ</i> formed uniform and elastic SEI for high-performance batteries

## Evaluation Papers

- #1: Lithium Batteries and the Solid Electrolyte Interphase (SEI)—Progress and Outlook
- #2: Designing superior solid electrolyte interfaces on silicon anodes for high-performance lithium-ion batteries

## Optional Peripheral Papers

- #68: Lithium-Ion Batteries
