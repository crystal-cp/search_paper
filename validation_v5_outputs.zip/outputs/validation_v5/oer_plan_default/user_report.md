# User-Friendly Literature Screening Summary

## How the system interpreted the task

The system split the question into intent groups, query families, domain checks, and evidence-grounded paper summaries.

## What to read first

| Rank | Paper | Evidence grounding | Intent match | Reading priority | Why this is shown |
| ---: | --- | --- | ---: | --- | --- |

## Important caveat

`strict_support` means the evidence sentence is grounded in the abstract. It does not by itself mean the paper is highly relevant.

## Provider status

- openalex: not_attempted (0 papers returned)
- semantic_scholar: not_attempted (0 papers returned)

## How to narrow the next run

Use feedback such as 'exclude sodium batteries' or 'show more in situ characterization methods' to refine the next pass.
