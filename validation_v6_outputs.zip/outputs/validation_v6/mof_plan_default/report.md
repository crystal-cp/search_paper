# Literature Screening Decision Report

## Research Question

我想了解 MOF 材料用于 CO2 捕集时孔径、官能团和水稳定性对吸附性能的影响，想找理论机制、实验表征、典型材料和应用限制相关论文。

## Question Preprocessing

Planning question: Find papers about MOF, adsorption performance, capture, CO2.

Translated question: Find papers about MOF, adsorption performance, capture, CO2.

## How the system corrected the user’s question

- User original wording: 我想了解 MOF 材料用于 CO2 捕集时孔径、官能团和水稳定性对吸附性能的影响，想找理论机制、实验表征、典型材料和应用限制相关论文。
- Expert rewritten question: Find papers about MOF, adsorption performance, capture, CO2.
- Downweighted user terms: 
- Expert concepts added: MOF, representative materials, application limitations, MOF CO2, theoretical mechanism, adsorption performance, capture, CO2, carbon dioxide, experimental characterization

## Intent assumptions and possible misreadings

- Possible interpretations of the user's wording:
  - direct citation or same-author related papers
  - topic-related papers
  - method-related papers
  - application-related papers
  - theory-lineage related papers
- Selected interpretation: topic + method + theory-lineage related papers
- Why this interpretation: The question mentions research concepts and probe goals, but no verified citation relation; topical, methodological, and theory-lineage relevance is the safest default.
- Ambiguity points:
  - The phrase 'related papers' is ambiguous: it may mean direct citation, same author, topical similarity, method overlap, application relevance, or theory lineage.
- Needs user confirmation:
  - Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance.
- Unsafe or overbroad assumptions avoided:
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.
- User words not mechanically used as hard query terms: none recorded

LLM-assisted intent repair:
- LLM attempted: False
- LLM used: False
- Fallback used: True
- LLM confidence: 0.0
- Fallback reason: llm_not_requested

Concepts supplemented for expert-style planning:

| Concept | Category | Source | Role | Used in provider query | Activation reason |
| --- | --- | --- | --- | ---: | --- |
| MOF | object | user_text | must | yes | Explicit or translated research object appears in the user question. |
| adsorption performance | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| capture | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| CO2 | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| carbon dioxide | material | user_text | optional | yes | Explicit or translated domain context appears in the user question. |
| water stability | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| functional groups | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| pore size | property | user_text | optional | yes | Explicit or translated target property/process appears in the user question. |
| experimental characterization | method | user_text | optional | yes | User asks for methods, characterization, workflow, or measurement evidence. |
| theoretical mechanism | mechanism | user_text | optional | yes | User asks for theory or mechanism evidence. |
| representative materials | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| application limitations | object | user_text | optional | yes | Additional explicit or glossary-supported scientific term from the user question. |
| MOF CO2 | object | user_text | optional | yes | Candidate topic phrase appears in the user question. |

Optional or uncertain concepts: adsorption performance, capture, CO2, carbon dioxide, water stability, functional groups, pore size, experimental characterization, theoretical mechanism, representative materials, application limitations, MOF CO2

Needs user confirmation: Confirm whether 'related' should mean direct citation/same-author papers, or broader topical/method/theory-lineage relevance.
- Assumptions needing confirmation or verification:
  - No domain-specific intent repair rules matched.
  - Do not treat broad motivation words as hard retrieval requirements.
  - Assume 'related papers' means topic + method + theory-lineage relevance unless the user asks for citation or author-only expansion.
- Conservative boundaries:
  - Do not infer citation relations unless citation/snowballing artifacts verify them.
  - Do not inject unrelated domain-pack terms without an activation rule.
  - Do not treat 'related papers' as verified citation relation or same-author relation without seed/citation evidence.

## What the System Thinks the User Is Looking For

- Refined question: Find papers about MOF, adsorption performance, capture, CO2.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Inclusion criteria: materials experimental theoretical mechanism effect applications mof co2, MOF, representative materials, application limitations, MOF CO2, theoretical mechanism, experimental characterization
- Exclusion criteria: 
- Required aspects: materials, experimental, theoretical, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Preferred paper types: review, survey, tutorial, methodological paper, theoretical paper
- Time window: no strict time window
- Success definition: A small set of background papers plus clear concepts.

## Search Contract

- Domain: general_science
- Positive domains: science
- Negative domains: 
- Must include concepts: MOF
- Must exclude concepts: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, application_performance: application; performance; activity; accuracy; recall; metric, failure_limitation: failure; limitation; degradation; aging; stability, MOF
- Field whitelist: 
- Field blacklist: 

## Ambiguity Handling

- No ambiguous terms were detected.

## Refined Subquestions

- No subquestions were needed for this run.

## Query Strategy

- Core terms: MOF, adsorption performance, capture, CO2, carbon dioxide, water stability, functional groups, pore size, experimental characterization, theoretical mechanism, representative materials, application limitations, MOF CO2
- Must terms: MOF
- Optional terms: adsorption performance, capture, CO2, carbon dioxide, water stability, functional groups, pore size, experimental characterization, theoretical mechanism, representative materials
- Exclude terms: 
- Required aspects: review_background: review; background; overview; introduction, theory_mechanism: theory; mechanism; model; explanation, methods_characterization: method; characterization; measurement; probe; experiment, materials_cases: material; system; case study; benchmark, application_performance: application; performance; activity; accuracy; recall; metric, failure_limitation: failure; limitation; degradation; aging; stability, MOF
- Filters: {'strictness': 'balanced', 'openalex_mode': 'keyword+semantic', 'sort_preference': 'relevance', 'ranking_profile': 'balanced', 'search_contract_domain': 'general_science', 'intent_domain': 'general_science', 'must_term_groups': [['MOF'], ['MOF'], ['adsorption performance', 'capture', 'CO2', 'carbon dioxide', 'adsorption']], 'constraint_groups': [{'group_name': 'must_concepts', 'operator': 'OR', 'terms': ['MOF'], 'source': 'expert_intent', 'required': True}, {'group_name': 'optional_high_confidence', 'operator': 'OR', 'terms': ['adsorption performance', 'capture', 'CO2', 'carbon dioxide', 'water stability', 'functional groups', 'pore size', 'experimental characterization', 'theoretical mechanism', 'representative materials', 'application limitations', 'MOF CO2'], 'source': 'expert_intent', 'required': False}, {'group_name': 'core_object_group', 'operator': 'OR', 'terms': ['MOF'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'domain_context_group', 'operator': 'OR', 'terms': ['adsorption performance', 'capture', 'CO2', 'carbon dioxide', 'adsorption'], 'source': 'generic_intent_frame', 'required': True}, {'group_name': 'process_or_property_group', 'operator': 'OR', 'terms': ['water stability', 'functional groups', 'pore size', 'performance'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'method_group', 'operator': 'OR', 'terms': ['experimental characterization'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'mechanism_group', 'operator': 'OR', 'terms': ['theoretical mechanism'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'material_or_case_group', 'operator': 'OR', 'terms': ['adsorption performance', 'capture', 'CO2', 'carbon dioxide'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'application_or_metric_group', 'operator': 'OR', 'terms': ['adsorption performance', 'capture', 'application limitations', 'adsorption', 'performance'], 'source': 'generic_intent_frame', 'required': False}, {'group_name': 'failure_or_limitation_group', 'operator': 'OR', 'terms': ['water stability', 'application limitations'], 'source': 'generic_intent_frame', 'required': False}], 'terminology_map': {}, 'intent_materials': ['adsorption performance', 'capture', 'CO2', 'carbon dioxide'], 'intent_methods': ['experimental characterization'], 'intent_repair_used': True, 'structured_concepts': [{'term': 'MOF', 'category': 'object', 'source': 'user_text', 'confidence': 0.86, 'activation_reason': 'Explicit or translated research object appears in the user question.', 'query_role': 'must', 'should_use_in_provider_query': True}, {'term': 'adsorption performance', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'capture', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'CO2', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'carbon dioxide', 'category': 'material', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated domain context appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'water stability', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'functional groups', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'pore size', 'category': 'property', 'source': 'user_text', 'confidence': 0.82, 'activation_reason': 'Explicit or translated target property/process appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'experimental characterization', 'category': 'method', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for methods, characterization, workflow, or measurement evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'theoretical mechanism', 'category': 'mechanism', 'source': 'user_text', 'confidence': 0.8, 'activation_reason': 'User asks for theory or mechanism evidence.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'representative materials', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'application limitations', 'category': 'object', 'source': 'user_text', 'confidence': 0.78, 'activation_reason': 'Additional explicit or glossary-supported scientific term from the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}, {'term': 'MOF CO2', 'category': 'object', 'source': 'user_text', 'confidence': 0.72, 'activation_reason': 'Candidate topic phrase appears in the user question.', 'query_role': 'optional', 'should_use_in_provider_query': True}]}


# Research Process

## 1. Research question interpretation

- Original question: 我想了解 MOF 材料用于 CO2 捕集时孔径、官能团和水稳定性对吸附性能的影响，想找理论机制、实验表征、典型材料和应用限制相关论文。
- Refined question: Find papers about MOF, adsorption performance, capture, CO2.
- Search intent: overview
- User goal: Find papers aligned with the user's research question.
- Domain: general_science
- Must include concepts: MOF
- Must exclude concepts: 
- Core terms: MOF, adsorption performance, capture, CO2, carbon dioxide, water stability, functional groups, pore size
- Expert rewrite: Find papers about MOF, adsorption performance, capture, CO2.
- Downweighted user terms: 

## 2. Concept decomposition

- Domain: general_science
- Central question: 我想了解 MOF 材料用于 CO2 捕集时孔径、官能团和水稳定性对吸附性能的影响，想找理论机制、实验表征、典型材料和应用限制相关论文。 Find papers about MOF, adsorption performance, capture, CO2.
- core_topic: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption
- theory_mechanism: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption
- characterization_methods: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption
- materials_or_cases: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption
- application_or_performance: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption
- failure_or_limitation: concepts=MOF, water stability, functional groups, pore size, performance; methods=experimental characterization; materials=adsorption performance, capture, CO2, carbon dioxide, adsorption

## 3. Search lenses and query families

- Query families generated: 7
- core_topic (lens=core_topic): anchor retrieval around the core research object and context; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- theory_mechanism (lens=theory_mechanism): find theory, mechanism, model, or causal-relation papers; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- characterization_methods (lens=characterization_methods): find experimental, computational, screening, or characterization methods; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- materials_or_cases (lens=materials_or_cases): find representative materials, systems, benchmarks, or case studies; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- application_or_performance (lens=application_or_performance): find applications, device relevance, activity, metrics, or performance papers; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- failure_or_limitation (lens=failure_or_limitation): find failure modes, degradation, limitations, or boundary conditions; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"
- performance_metrics (lens=performance_metrics): find recall, accuracy, and evaluation-metric evidence; sample queries=openalex: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups" \| semantic_scholar: MOF "CO2 adsorption" "pore size"; MOF "CO2 capture" "functional groups"

## 4. Screening and inclusion criteria

- Inclusion criteria: materials experimental theoretical mechanism effect applications mof co2, MOF, representative materials, application limitations, MOF CO2, theoretical mechanism, experimental characterization
- Exclusion criteria: 
- Required aspects: materials, experimental, theoretical, background, significance, core concept coverage, method or measurement evidence, representative case coverage
- Contract inclusion criteria: materials experimental theoretical mechanism effect applications mof co2, MOF, representative materials, application limitations, MOF CO2, theoretical mechanism, experimental characterization
- Contract exclusion criteria: 

## 5. Paper roles and why they matter

- theory_origin: 0 paper(s)
- conceptual_framework: 0 paper(s)
- experimental_proof: 0 paper(s)
- surface_probe_method: 0 paper(s)
- nanoscale_readout: 0 paper(s)
- application_bridge: 0 paper(s)
- frontier_extension: 0 paper(s)
- limitation_or_challenge: 0 paper(s)
- review_background: 0 paper(s)

## 6. Research lineage

Not generated in this run.
- citation relation not verified unless explicit citation-expansion artifacts support it.

## 7. Controversies, limitations, and gaps

- Gap: Theory and mechanism background is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Characterization methods are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Representative material cases are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Application or performance evidence is undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).
- Gap: Failure mechanisms are undercovered: 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s).

## 8. Missing keywords, methods, authors, or schools

- Gap-derived missing directions:
  - Theory and mechanism background is undercovered: 
  - Characterization methods are undercovered: 
  - Representative material cases are undercovered: 
  - Application or performance evidence is undercovered: 
  - Failure mechanisms are undercovered: 
- Lens methods to audit: experimental characterization
- Lens materials to audit: adsorption performance, capture, CO2, carbon dioxide, adsorption
- Author hints from seed mentions: 
- School/lab inference was not generated; needs further verification.

## 9. Suggested next searches

- MOF "research gap"
- MOF characterization method comparison
- MOF representative material case study
- MOF application performance metric
- MOF "failure mechanism" degradation

## 10. Verified vs uncertain findings

- Verified:
  - No strict or span-validated findings were available.
- Uncertain:
  - No uncertain findings were identified.
- Evidence functions observed: 

## Planned Queries

- MOF "CO2 adsorption" "pore size"
- MOF "CO2 capture" "functional groups"
- MOF "CO2 adsorption" "water stability"
- MOF "CO2 capture" "adsorption performance"
- MOF "metal-organic framework" "carbon dioxide adsorption" mechanism
- MOF "CO2 capture" "structure property relationship"
- MOF "CO2 adsorption" review
- MOF "CO2 capture" "representative frameworks"

## Domain Guardrails

- In scope: 0
- Borderline: 0
- Out of scope: 0

- No papers were demoted by domain guardrails.

## Query Pilot Diagnostics

- Pilot search was not run for this report.

## Query Repairs Applied

- Auto repair applied: False

| Provider | Recommendation | Original query | Repaired query | Reason |
| --- | --- | --- | --- | --- |
|  |  |  |  | static_query_quality_repair |

## Seed Paper Expansion

- No user-provided seed papers were supplied. If snowballing was enabled, seeds were selected from high-confidence ranked papers when possible.

- No citation/reference/recommendation expansion paths were recorded for this run.


## Retrieval Summary

- Raw retrieved paper count: 0
- Merged paper count: 0
- Duplicate count: 0
- Counts by provider: {'openalex': 0, 'semantic_scholar': 0}
- Imported library papers: 0
- Imported library format: none
- Year filter enabled: False
- From year: None
- Records kept after year filter: 0
- Records excluded before from-year: 0
- Records excluded because year is missing: 0

## PRISMA-like Screening Flow

- Records identified by OpenAlex: 0
- Records identified by Semantic Scholar: 0
- Duplicate records removed: 0
- Records with missing abstracts: 0
- Records screened: 0
- Records included: 0
- Records maybe: 0
- Records excluded: 0
- Out-of-domain records: 0
- Included in top ranked results: 0
- Excluded or low confidence: 0
- Common exclusion reasons: {}

## Provider Status

| Provider | Status | Queries attempted | Papers returned | Notes |
| --- | --- | ---: | ---: | --- |
| openalex | not_attempted | 0 | 0 | stopped after 0 queries |
| semantic_scholar | not_attempted | 0 | 0 | stopped after 0 queries |

## LLM Settings

- Backend requested: none
- Backend active: none
- Planner mode: rule
- Extractor mode: rule
- Verifier mode: rule
- Invalid LLM output count: 0

## Evidence Validation

`strict_support` means the evidence sentence was grounded in the abstract. It is not a claim that the paper is highly relevant; use intent match and reading priority separately.

- Strict supported count: 0
- Weak support count: 0
- Unverified count: 0
- LLM invalid evidence count: 0
- Grounding accuracy: 0.000
- Strict support rate: 0.000
- Weak support rate: 0.000
- LLM invalid evidence rate: 0.000
- Average aspect coverage: 0.000

## Scoring Formula

`base_score = weighted relevance/evidence/recency/quality/diversity; pre_domain_score = 0.52 * intent_centrality_score + 0.48 * base_score when intent centrality is available; then domain penalty is applied`

Current weights:

- Relevance: 0.4
- Evidence: 0.25
- Recency: 0.15
- Quality: 0.15
- Diversity: 0.05
- Domain penalty: in_scope x1.0, borderline x0.7, out_of_scope x0.3

## Top 10 Ranked Papers

| Rank | Decision | Score | Evidence grounding | Intent match | Reading priority | Domain | Year | Title | Venue | DOI |
| --- | --- | ---: | --- | ---: | --- | --- | ---: | --- | --- | --- |

## Included Papers

- No papers were automatically marked include.

## Maybe / Needs Human Inspection

- No papers were marked maybe.

## Excluded Papers And Reasons

- No papers were automatically excluded.

## Common Exclusion Reasons

- No exclusion reasons were recorded.

## Method Comparison Matrix

- No method comparison rows were generated.

## Research Gap Matrix

| Gap | Supporting papers | Why gap remains | Possible project idea | Related aspects |
| --- | --- | --- | --- | --- |
| Theory and mechanism background is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Synthesize theoretical background with experimentally grounded mechanism evidence. | theory_mechanism: theory; mechanism; model; explanation |
| Characterization methods are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Build a method-comparison table across direct, indirect, in situ, and ex situ probes. | methods_characterization: method; characterization; measurement; probe; experiment |
| Representative material cases are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Benchmark representative materials or systems rather than relying on one prototype. | materials_cases: material; system; case study; benchmark |
| Application or performance evidence is undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Trace how mechanism or characterization evidence connects to performance metrics. | application_performance: application; performance; activity; accuracy; recall; metric |
| Failure mechanisms are undercovered | No strong supporting papers in this run | 1 signal(s) suggest this aspect is undercovered across 1 screened paper(s). | Map failure, degradation, and aging pathways to material systems and diagnostics. | failure_limitation: failure; limitation; degradation; aging; stability |

- Full matrix: `research_gap_matrix.csv` and `research_gap_matrix.md`.

## Suggested Next Searches

| Query | Reason | Source |
| --- | --- | --- |
| MOF "research gap" | Investigate undercovered gap: Theory and mechanism background is undercovered | research_gap_matrix |
| MOF characterization method comparison | Investigate undercovered gap: Characterization methods are undercovered | research_gap_matrix |
| MOF representative material case study | Investigate undercovered gap: Representative material cases are undercovered | research_gap_matrix |
| MOF application performance metric | Investigate undercovered gap: Application or performance evidence is undercovered | research_gap_matrix |
| MOF "failure mechanism" degradation | Investigate undercovered gap: Failure mechanisms are undercovered | research_gap_matrix |

- Full list: `suggested_next_searches.json` and `suggested_next_searches.md`.

## Research Tensions And Boundary Conditions

- No research tensions were identified from this run.

## Aspect Coverage Summary

- No required aspects were classified.

## Recommended Reading Path

- See `reading_path.md`.

## Result Groups

- must_read: 0 papers
- recent_frontier: 0 papers
- implementation_relevant: 0 papers
- evaluation_relevant: 0 papers
- background_or_survey: 0 papers
- peripheral: 0 papers
- excluded_or_low_confidence: 0 papers

## Top Paper Evidence Cards

- See `paper_cards.md`.

## Evidence Chain Table

| Rank | Support level | Span match | Span confidence | LLM invalid | Missing abstract | Claim | Evidence | Matched text |
| ---: | --- | --- | ---: | --- | --- | --- | --- | --- |

## Human Feedback Preference Learning

- Preference learning inactive: No include/exclude feedback labels were available.

## How feedback changed ranking

- Feedback applied: no

## Suggested query refinements from feedback

- No feedback-derived query refinements were generated.

## Evaluation Metrics

- Missing abstract ratio: 0.000
- Unsupported claim rate: 0.000
- Precision@10: None
- nDCG@10: None
- MAP: None
- Recall@10: None
- Feedback mean absolute rank delta: 0.0

## Agent Trace Summary

- Intent agent: overview
- Planner: 8 planned query strings.
- Retriever: 0 raw records, 0 merged records.
- Domain guardrail: 0 in_scope, 0 borderline, 0 out_of_scope.
- Screening decision agent: 0 include, 0 maybe, 0 exclude.
- Full trace: `agent_trace.json`.

## Limitations

- Retrieval depends on provider metadata quality and availability.
- Evidence extraction is lexical and abstract-only.
- Verification checks grounding in abstracts, not full-text claims.
- Ranking weights are transparent but manually chosen for the MVP.

## Future Work

- Add richer query expansion and provider diagnostics.
- Compare rule-based extraction with optional LLM extraction.
- Add a small human-labeling loop for iterative ranking studies.
- Add full-text or PDF support only after the abstract-level baseline is validated.
